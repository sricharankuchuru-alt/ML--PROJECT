/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TrafficRecord, WeatherCondition } from '../types/traffic';

const roadSegments = [
  'Metro Expressway (Northbound)',
  'Metro Expressway (Southbound)',
  'Airport Corridor (East)',
  'Central Boulevard (Downtown)',
  'Tech Park Highway',
  'Harbor Bay Bridge',
  'Outer Ring Road (Sector 4)',
  'Outer Ring Road (Sector 9)',
  'University Avenue',
  'Riverside Parkway',
  'Industrial Bypass Corridor',
  'Grand Avenue Arterial',
];

const weathers: WeatherCondition[] = ['Clear', 'Rainy', 'Foggy', 'Overcast'];

// Deterministic pseudo-random helper for consistent seedable generation
function pseudoRandom(seed: number) {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

// Generates 150 realistic traffic records with physical Greenshields correlation
export function generateSampleTrafficData(): TrafficRecord[] {
  const records: TrafficRecord[] = [];
  const baseLat = 37.7749;
  const baseLng = -122.4194;

  const roadAnchors = [
    { name: 'Metro Expressway (Northbound)', lat: 37.785, lng: -122.405, speedBase: 78, maxCap: 2400 },
    { name: 'Metro Expressway (Southbound)', lat: 37.783, lng: -122.408, speedBase: 75, maxCap: 2350 },
    { name: 'Airport Corridor (East)', lat: 37.742, lng: -122.392, speedBase: 85, maxCap: 2200 },
    { name: 'Central Boulevard (Downtown)', lat: 37.791, lng: -122.412, speedBase: 42, maxCap: 1600 },
    { name: 'Tech Park Highway', lat: 37.765, lng: -122.388, speedBase: 68, maxCap: 2100 },
    { name: 'Harbor Bay Bridge', lat: 37.798, lng: -122.378, speedBase: 70, maxCap: 2500 },
    { name: 'Outer Ring Road (Sector 4)', lat: 37.732, lng: -122.435, speedBase: 82, maxCap: 2000 },
    { name: 'Outer Ring Road (Sector 9)', lat: 37.755, lng: -122.465, speedBase: 80, maxCap: 1950 },
    { name: 'University Avenue', lat: 37.771, lng: -122.448, speedBase: 45, maxCap: 1400 },
    { name: 'Riverside Parkway', lat: 37.805, lng: -122.425, speedBase: 55, maxCap: 1550 },
    { name: 'Industrial Bypass Corridor', lat: 37.725, lng: -122.402, speedBase: 62, maxCap: 1700 },
    { name: 'Grand Avenue Arterial', lat: 37.781, lng: -122.429, speedBase: 48, maxCap: 1500 },
  ];

  // 150 records across 24-hour cycle
  const timestamps = [
    '06:15', '06:45', '07:10', '07:30', '07:50', '08:15', '08:35', '08:50',
    '09:15', '09:40', '10:15', '11:00', '12:15', '13:30', '14:20', '15:15',
    '16:00', '16:45', '17:15', '17:40', '18:05', '18:30', '18:55', '19:30',
    '20:15', '21:00', '22:30', '23:45'
  ];

  let seed = 42;

  for (let i = 1; i <= 150; i++) {
    const road = roadAnchors[(i - 1) % roadAnchors.length];
    const timeIndex = (i * 3 + Math.floor(i / 10)) % timestamps.length;
    const timeStr = timestamps[timeIndex];
    const hour = parseInt(timeStr.split(':')[0], 10);
    const minute = timeStr.split(':')[1];
    const datePrefix = '2026-10-04';

    const r1 = pseudoRandom(seed++);
    const r2 = pseudoRandom(seed++);
    const r3 = pseudoRandom(seed++);

    // Determine traffic regime based on hour:
    // Peak hours: 07:30 - 09:30 and 17:00 - 19:30
    const isMorningPeak = hour >= 7 && hour <= 9;
    const isEveningPeak = hour >= 17 && hour <= 19;
    const isPeak = isMorningPeak || isEveningPeak;
    const isNight = hour >= 22 || hour <= 5;

    let speed = 0;
    let density = 0;
    let volume = 0;
    let isOutlier = false;

    // Introduce intentionally 6-8 distinctive realistic outliers (accidents, road closure, anomalous sensor spike)
    if (i === 14 || i === 47 || i === 83 || i === 112 || i === 138) {
      isOutlier = true;
      if (i === 14) {
        // Sudden accident: near zero speed (8 km/h), high density (95 veh/km), but low throughput/volume (310 veh/hr)
        speed = 8;
        density = 96;
        volume = 320;
      } else if (i === 47) {
        // Anomalous sensor spike: very high volume with moderate density
        speed = 52;
        density = 38;
        volume = 2950;
      } else if (i === 83) {
        // Roadblock detour: high speed in unexpected corridor with almost zero volume
        speed = 98;
        density = 6;
        volume = 140;
      } else if (i === 112) {
        // Extreme bottleneck breakdown
        speed = 11;
        density = 104;
        volume = 410;
      } else {
        // Phantom jam oscillation
        speed = 18;
        density = 88;
        volume = 680;
      }
    } else if (isPeak) {
      // Congested or Heavy Flow
      const severeCongestion = r1 > 0.45;
      if (severeCongestion) {
        speed = Math.round(12 + r2 * 14); // 12 - 26 km/h
        density = Math.round(72 + r3 * 26); // 72 - 98 veh/km
        volume = Math.round(speed * density * 0.95); // 850 - 1800 veh/hr
      } else {
        // Heavy traffic
        speed = Math.round(28 + r2 * 18); // 28 - 46 km/h
        density = Math.round(48 + r3 * 22); // 48 - 70 veh/km
        volume = Math.round(1450 + r1 * 600); // 1450 - 2050 veh/hr
      }
    } else if (isNight) {
      // Free Flow late night
      speed = Math.round(road.speedBase * (0.95 + r1 * 0.25)); // 65 - 95 km/h
      density = Math.round(8 + r2 * 12); // 8 - 20 veh/km
      volume = Math.round(200 + r3 * 450); // 200 - 650 veh/hr
    } else {
      // Moderate / Normal daytime flow
      speed = Math.round(road.speedBase * (0.65 + r1 * 0.25)); // 40 - 65 km/h
      density = Math.round(24 + r2 * 22); // 24 - 46 veh/km
      volume = Math.round(1050 + r3 * 650); // 1050 - 1700 veh/hr
    }

    // Weather impact
    const weatherRoll = pseudoRandom(seed++);
    let weather: WeatherCondition = 'Clear';
    if (weatherRoll > 0.82) {
      weather = 'Rainy';
      speed = Math.max(10, Math.round(speed * 0.84));
    } else if (weatherRoll > 0.72) {
      weather = 'Foggy';
      speed = Math.max(12, Math.round(speed * 0.88));
    } else if (weatherRoll > 0.55) {
      weather = 'Overcast';
    }

    // Slight spatial jitter along the road anchor
    const latJitter = (pseudoRandom(seed++) - 0.5) * 0.018;
    const lngJitter = (pseudoRandom(seed++) - 0.5) * 0.022;

    records.push({
      record_id: `TRF-${(1000 + i).toString()}`,
      road_segment: road.name,
      timestamp: `${datePrefix} ${timeStr}:00`,
      speed,
      traffic_volume: volume,
      traffic_density: density,
      weather,
      latitude: Number((road.lat + latJitter).toFixed(5)),
      longitude: Number((road.lng + lngJitter).toFixed(5)),
      is_outlier: isOutlier
    });
  }

  return records;
}
