/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TrafficStatus = 'Free Flow' | 'Moderate' | 'Heavy' | 'Congested';
export type WeatherCondition = 'Clear' | 'Rainy' | 'Foggy' | 'Overcast';

export interface TrafficRecord {
  record_id: string;
  road_segment: string;
  timestamp: string;
  speed: number;            // in km/h
  traffic_volume: number;   // in vehicles/hr
  traffic_density: number;  // in vehicles/km
  weather: WeatherCondition;
  latitude: number;
  longitude: number;
  kmeans_cluster?: number;
  dbscan_cluster?: number;
  traffic_status?: TrafficStatus;
  is_outlier?: boolean;
}

export interface ClusterCentroid {
  cluster: number;
  name: string;
  speed: number;
  traffic_volume: number;
  traffic_density: number;
  count: number;
  color: string;
  status: TrafficStatus;
}

export interface KMeansResult {
  k: number;
  centroids: ClusterCentroid[];
  inertia: number;
  silhouetteScore: number;
  daviesBouldinIndex: number;
  clusterCounts: Record<number, number>;
  elbowData: { k: number; inertia: number }[];
}

export interface DbscanResult {
  eps: number;
  minSamples: number;
  totalClusters: number;
  noiseCount: number;
  hotspotsCount: number;
  silhouetteScore: number;
  daviesBouldinIndex: number;
  clusterCounts: Record<number, number>; // -1 for noise
}

export interface ModelComparisonMetrics {
  metric: string;
  kmeans: string | number;
  dbscan: string | number;
  description: string;
  winner: 'kmeans' | 'dbscan' | 'tie';
}

export interface PreprocessingStats {
  totalRecords: number;
  missingValuesHandled: number;
  featuresSelected: string[];
  recordsProcessed: number;
  normalizationMethod: string;
  standardizedDimensions: number;
}

export interface FilterOptions {
  search: string;
  status: string;
  roadSegment: string;
  weather: string;
  kmeansCluster: string;
  dbscanCluster: string;
}
