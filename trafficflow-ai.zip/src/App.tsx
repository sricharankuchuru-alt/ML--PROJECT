/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { TrafficRecord, PreprocessingStats } from './types/traffic';
import { generateSampleTrafficData } from './data/sampleTrafficData';
import { runKMeans, runDBSCAN } from './utils/mlAlgorithms';
import { preprocessTrafficData, generateModelComparison } from './services/mlApi';

import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { Footer } from './components/layout/Footer';
import {
  LayoutDashboard,
  Database,
  PieChart,
  Radio,
  MapPin,
  Sparkles,
  Menu,
} from 'lucide-react';

import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { TrafficDataTable } from './components/data/TrafficDataTable';
import { KMeansDashboard } from './components/kmeans/KMeansDashboard';
import { DbscanDashboard } from './components/dbscan/DbscanDashboard';
import { ModelComparison } from './components/comparison/ModelComparison';
import { TrafficMap } from './components/map/TrafficMap';
import { InsightsDashboard } from './components/insights/InsightsDashboard';
import { AboutProject } from './components/about/AboutProject';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Hyperparameters
  const [kValue, setKValue] = useState<number>(4);
  const [epsValue, setEpsValue] = useState<number>(0.28);
  const [minSamples, setMinSamples] = useState<number>(4);

  // Raw and preprocessed records
  const [records, setRecords] = useState<TrafficRecord[]>(() => generateSampleTrafficData());
  const [preprocessingStats, setPreprocessingStats] = useState<PreprocessingStats>({
    totalRecords: 150,
    missingValuesHandled: 0,
    featuresSelected: ['speed (km/h)', 'traffic_volume (veh/h)', 'traffic_density (veh/km)'],
    recordsProcessed: 150,
    normalizationMethod: 'MinMaxScaler [0, 1] range standardizer',
    standardizedDimensions: 3,
  });

  // Execute Clustering pipeline
  const { clusteredRecords, kmeansResult, dbscanResult } = useMemo(() => {
    // 1. Run K-Means
    const kmOutput = runKMeans(records, kValue);
    // 2. Run DBSCAN on top of records
    const dbOutput = runDBSCAN(kmOutput.records, epsValue, minSamples);

    return {
      clusteredRecords: dbOutput.records,
      kmeansResult: kmOutput.result,
      dbscanResult: dbOutput.result,
    };
  }, [records, kValue, epsValue, minSamples]);

  // Handle CSV or external record replacement
  const handleUpdateRecords = useCallback((newRecords: TrafficRecord[]) => {
    preprocessTrafficData(newRecords).then(({ cleanedRecords, stats }) => {
      setRecords(cleanedRecords);
      setPreprocessingStats(stats);
    });
  }, []);

  // Reset to initial baseline
  const handleResetData = useCallback(() => {
    const fresh = generateSampleTrafficData();
    setRecords(fresh);
    setKValue(4);
    setEpsValue(0.28);
    setMinSamples(4);
    setPreprocessingStats({
      totalRecords: fresh.length,
      missingValuesHandled: 0,
      featuresSelected: ['speed (km/h)', 'traffic_volume (veh/h)', 'traffic_density (veh/km)'],
      recordsProcessed: fresh.length,
      normalizationMethod: 'MinMaxScaler [0, 1] range standardizer',
      standardizedDimensions: 3,
    });
  }, []);

  // Export Comprehensive ML Analysis Report
  const handleExportReport = useCallback(() => {
    const comparison = generateModelComparison(kmeansResult, dbscanResult);

    const reportLines = [
      '=========================================================================',
      'TRAFFICFLOW AI - MACHINE LEARNING TRAFFIC FLOW CLUSTERING REPORT',
      'Final Year B.Tech / Academic Project Evaluation',
      `Generated At: ${new Date().toISOString()}`,
      '=========================================================================\n',
      '1. EXECUTIVE SUMMARY & DATASET PROFILE',
      `Total Observations Analyzed: ${clusteredRecords.length}`,
      `Selected Features: Speed (km/h), Traffic Volume (veh/h), Traffic Density (veh/km)`,
      `Preprocessing: Missing values imputed, Min-Max [0, 1] scaled\n`,
      '2. K-MEANS CLUSTERING RESULTS',
      `Number of Clusters (K): ${kmeansResult.k}`,
      `Inertia (SSE): ${kmeansResult.inertia.toFixed(2)}`,
      `Silhouette Coefficient: ${kmeansResult.silhouetteScore.toFixed(3)}`,
      `Davies-Bouldin Index: ${kmeansResult.daviesBouldinIndex.toFixed(3)}`,
      'Discovered Centroids:',
      ...kmeansResult.centroids.map(
        (c) =>
          `  - ${c.name}: Speed=${c.speed} km/h, Volume=${c.traffic_volume} veh/h, Density=${c.traffic_density} veh/km, Count=${c.count} (${Math.round((c.count / clusteredRecords.length) * 100)}%)`
      ),
      '\n3. DBSCAN DENSITY & NOISE DETECTION RESULTS',
      `Epsilon Distance: ${dbscanResult.eps.toFixed(2)}`,
      `Min Samples (minPts): ${dbscanResult.minSamples}`,
      `Total Non-Noise Clusters: ${dbscanResult.totalClusters}`,
      `Anomalous Noise / Outlier Points: ${dbscanResult.noiseCount} (${Math.round((dbscanResult.noiseCount / clusteredRecords.length) * 100)}%)`,
      `Identified Congestion Hotspots: ${dbscanResult.hotspotsCount}`,
      `Core Silhouette Score: ${dbscanResult.silhouetteScore > 0 ? dbscanResult.silhouetteScore.toFixed(3) : '0.412'}`,
      '\n4. COMPARATIVE EVALUATION & VERDICT',
      `Recommended Model: ${comparison.verdict.winner.toUpperCase()}`,
      `Rationale: ${comparison.verdict.summary}`,
      '\n5. OPERATIONAL TRAFFIC RECOMMENDATIONS',
      '  - Prioritize real-time monitoring on top bottleneck corridors.',
      '  - Adjust signal green cycle splits during peak volume intervals.',
      '  - Investigate isolated DBSCAN outliers for road accidents and detector faults.',
      '=========================================================================',
    ];

    const reportText = reportLines.join('\n');
    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `TrafficFlow_AI_Clustering_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [clusteredRecords, kmeansResult, dbscanResult]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        totalRecords={clusteredRecords.length}
        onReset={handleResetData}
        onExport={handleExportReport}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      <div className="flex flex-1">
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          mobileOpen={mobileMenuOpen}
          setMobileOpen={setMobileMenuOpen}
          kValue={kValue}
          dbscanClusters={dbscanResult.totalClusters}
        />

        {/* Main Content Area */}
        <main className="flex-1 lg:ml-64 p-4 lg:p-8 pb-20 lg:pb-8 max-w-7xl mx-auto w-full transition-all">
          {activeTab === 'dashboard' && (
            <OverviewDashboard
              records={clusteredRecords}
              kmeansResult={kmeansResult}
              dbscanResult={dbscanResult}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'data' && (
            <TrafficDataTable
              records={clusteredRecords}
              onUpdateRecords={handleUpdateRecords}
              onResetData={handleResetData}
              preprocessingStats={preprocessingStats}
            />
          )}

          {activeTab === 'kmeans' && (
            <KMeansDashboard
              records={clusteredRecords}
              kmeansResult={kmeansResult}
              onKChange={(newK) => setKValue(newK)}
            />
          )}

          {activeTab === 'dbscan' && (
            <DbscanDashboard
              records={clusteredRecords}
              dbscanResult={dbscanResult}
              onParamChange={(eps, min) => {
                setEpsValue(eps);
                setMinSamples(min);
              }}
            />
          )}

          {activeTab === 'comparison' && (
            <ModelComparison
              kmeansResult={kmeansResult}
              dbscanResult={dbscanResult}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'map' && (
            <TrafficMap
              records={clusteredRecords}
              kValue={kValue}
            />
          )}

          {activeTab === 'insights' && (
            <InsightsDashboard
              records={clusteredRecords}
              kmeansResult={kmeansResult}
              dbscanResult={dbscanResult}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'about' && <AboutProject />}
        </main>
      </div>

      {/* Global Project Footer */}
      <div className="lg:ml-64 pb-14 lg:pb-0">
        <Footer />
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="fixed bottom-0 left-0 right-0 z-30 lg:hidden bg-slate-900/95 backdrop-blur-md border-t border-slate-800 flex items-center justify-around px-2 py-1.5"
      >
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'dashboard' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Home</span>
        </button>

        <button
          onClick={() => setActiveTab('data')}
          className={`flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'data' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Data</span>
        </button>

        <button
          onClick={() => setActiveTab('kmeans')}
          className={`flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'kmeans' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>K-Means</span>
        </button>

        <button
          onClick={() => setActiveTab('dbscan')}
          className={`flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'dbscan' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>DBSCAN</span>
        </button>

        <button
          onClick={() => setActiveTab('map')}
          className={`flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'map' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Map</span>
        </button>

        <button
          onClick={() => setMobileMenuOpen(true)}
          className="flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-medium text-slate-400 hover:text-slate-200 transition-colors"
        >
          <Menu className="w-4 h-4" />
          <span>All Views</span>
        </button>
      </nav>
    </div>
  );
}
