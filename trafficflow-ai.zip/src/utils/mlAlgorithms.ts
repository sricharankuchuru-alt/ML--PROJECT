/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TrafficRecord, TrafficStatus, ClusterCentroid, KMeansResult, DbscanResult } from '../types/traffic';

export interface ScaledPoint {
  index: number;
  features: number[]; // [speed, volume, density] normalized
  original: TrafficRecord;
}

// Min-Max or Standard scaling for multi-attribute ML distance metrics
export function scaleFeatures(records: TrafficRecord[]): {
  scaled: ScaledPoint[];
  minVals: number[];
  maxVals: number[];
} {
  if (records.length === 0) return { scaled: [], minVals: [], maxVals: [] };

  const speeds = records.map(r => r.speed);
  const volumes = records.map(r => r.traffic_volume);
  const densities = records.map(r => r.traffic_density);

  const minVals = [Math.min(...speeds), Math.min(...volumes), Math.min(...densities)];
  const maxVals = [Math.max(...speeds), Math.max(...volumes), Math.max(...densities)];

  const scaled = records.map((record, index) => {
    const s = maxVals[0] > minVals[0] ? (record.speed - minVals[0]) / (maxVals[0] - minVals[0]) : 0;
    const v = maxVals[1] > minVals[1] ? (record.traffic_volume - minVals[1]) / (maxVals[1] - minVals[1]) : 0;
    const d = maxVals[2] > minVals[2] ? (record.traffic_density - minVals[2]) / (maxVals[2] - minVals[2]) : 0;
    return {
      index,
      features: [s, v, d],
      original: record
    };
  });

  return { scaled, minVals, maxVals };
}

// Euclidean distance in n-dimensional normalized space
function euclideanDistance(a: number[], b: number[]): number {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

// Assign semantic traffic status based on speed & density
export function determineTrafficStatus(speed: number, density: number): TrafficStatus {
  if (speed < 25 || density >= 70) return 'Congested';
  if (speed < 42 || density >= 48) return 'Heavy';
  if (speed < 62 || density >= 28) return 'Moderate';
  return 'Free Flow';
}

// Distinct cluster color palette for data visualizations
export const CLUSTER_COLORS = [
  '#10B981', // Emerald - Free Flow
  '#38BDF8', // Cyan / Sky - Moderate
  '#F59E0B', // Amber - Heavy
  '#EF4444', // Red - Congested
  '#8B5CF6', // Violet - Special cluster 4
  '#EC4899', // Pink - Special cluster 5
  '#06B6D4', // Teal - Special cluster 6
  '#6366F1', // Indigo - Special cluster 7
];

export const NOISE_COLOR = '#A855F7'; // Purple for DBSCAN noise

// Run K-Means algorithm
export function runKMeans(
  records: TrafficRecord[],
  k: number = 4,
  maxIterations: number = 25
): { records: TrafficRecord[]; result: KMeansResult } {
  if (records.length === 0) {
    return {
      records: [],
      result: {
        k,
        centroids: [],
        inertia: 0,
        silhouetteScore: 0,
        daviesBouldinIndex: 0,
        clusterCounts: {},
        elbowData: []
      }
    };
  }

  const { scaled } = scaleFeatures(records);
  const n = scaled.length;
  const effectiveK = Math.min(k, n);

  // K-Means++ initialization
  const centroids: number[][] = [];
  centroids.push([...scaled[Math.floor(n / 2)].features]);

  for (let c = 1; c < effectiveK; c++) {
    const distances = scaled.map(pt => {
      let minDist = Infinity;
      for (const center of centroids) {
        const d = euclideanDistance(pt.features, center);
        if (d < minDist) minDist = d;
      }
      return minDist * minDist;
    });

    const sumDist = distances.reduce((acc, v) => acc + v, 0);
    let target = (sumDist * (c * 0.28 + 0.1)) % sumDist;
    let chosenIdx = 0;
    let running = 0;
    for (let i = 0; i < distances.length; i++) {
      running += distances[i];
      if (running >= target) {
        chosenIdx = i;
        break;
      }
    }
    centroids.push([...scaled[chosenIdx].features]);
  }

  let assignments = new Array(n).fill(0);

  // Iterations
  for (let iter = 0; iter < maxIterations; iter++) {
    let changed = false;

    // 1. Assign points to nearest centroid
    for (let i = 0; i < n; i++) {
      let minDist = Infinity;
      let closest = 0;
      for (let c = 0; c < effectiveK; c++) {
        const dist = euclideanDistance(scaled[i].features, centroids[c]);
        if (dist < minDist) {
          minDist = dist;
          closest = c;
        }
      }
      if (assignments[i] !== closest) {
        assignments[i] = closest;
        changed = true;
      }
    }

    // 2. Recompute centroids
    const counts = new Array(effectiveK).fill(0);
    const sums: number[][] = Array.from({ length: effectiveK }, () => [0, 0, 0]);

    for (let i = 0; i < n; i++) {
      const c = assignments[i];
      counts[c]++;
      sums[c][0] += scaled[i].features[0];
      sums[c][1] += scaled[i].features[1];
      sums[c][2] += scaled[i].features[2];
    }

    for (let c = 0; c < effectiveK; c++) {
      if (counts[c] > 0) {
        centroids[c][0] = sums[c][0] / counts[c];
        centroids[c][1] = sums[c][1] / counts[c];
        centroids[c][2] = sums[c][2] / counts[c];
      }
    }

    if (!changed) break;
  }

  // Calculate inertia (Sum of squared errors)
  let inertia = 0;
  for (let i = 0; i < n; i++) {
    const c = assignments[i];
    const dist = euclideanDistance(scaled[i].features, centroids[c]);
    inertia += dist * dist;
  }

  // Compute cluster averages in original unit domain
  const clusterCounts: Record<number, number> = {};
  for (let c = 0; c < effectiveK; c++) clusterCounts[c] = 0;

  const clusterCentroids: ClusterCentroid[] = [];
  for (let c = 0; c < effectiveK; c++) {
    const pts = records.filter((_, idx) => assignments[idx] === c);
    clusterCounts[c] = pts.length;
    const avgSpeed = pts.length ? Math.round(pts.reduce((s, p) => s + p.speed, 0) / pts.length) : 0;
    const avgVol = pts.length ? Math.round(pts.reduce((s, p) => s + p.traffic_volume, 0) / pts.length) : 0;
    const avgDen = pts.length ? Math.round(pts.reduce((s, p) => s + p.traffic_density, 0) / pts.length) : 0;

    let status = determineTrafficStatus(avgSpeed, avgDen);
    let name = `Cluster ${c} – ${status}`;

    clusterCentroids.push({
      cluster: c,
      name,
      speed: avgSpeed,
      traffic_volume: avgVol,
      traffic_density: avgDen,
      count: pts.length,
      color: CLUSTER_COLORS[c % CLUSTER_COLORS.length],
      status
    });
  }

  // Silhouette Score calculation
  const silhouetteScore = calculateSilhouetteScore(scaled, assignments, effectiveK);
  const daviesBouldinIndex = calculateDaviesBouldin(scaled, assignments, centroids, effectiveK);

  // Compute Elbow curve for k=2..8
  const elbowData = calculateElbowCurve(scaled);

  // Update records with assigned clusters and status
  const updatedRecords = records.map((rec, idx) => {
    const assignedCluster = assignments[idx];
    const status = determineTrafficStatus(rec.speed, rec.traffic_density);
    return {
      ...rec,
      kmeans_cluster: assignedCluster,
      traffic_status: status
    };
  });

  return {
    records: updatedRecords,
    result: {
      k: effectiveK,
      centroids: clusterCentroids,
      inertia: Number(inertia.toFixed(2)),
      silhouetteScore: Number(silhouetteScore.toFixed(3)),
      daviesBouldinIndex: Number(daviesBouldinIndex.toFixed(3)),
      clusterCounts,
      elbowData
    }
  };
}

// Run DBSCAN algorithm
export function runDBSCAN(
  records: TrafficRecord[],
  eps: number = 0.28,
  minSamples: number = 4
): { records: TrafficRecord[]; result: DbscanResult } {
  if (records.length === 0) {
    return {
      records: [],
      result: {
        eps,
        minSamples,
        totalClusters: 0,
        noiseCount: 0,
        hotspotsCount: 0,
        silhouetteScore: 0,
        daviesBouldinIndex: 0,
        clusterCounts: {}
      }
    };
  }

  const { scaled } = scaleFeatures(records);
  const n = scaled.length;

  const UNVISITED = 0;
  const VISITED = 1;
  const NOISE = -1;

  const status = new Array(n).fill(UNVISITED);
  const clusterAssignment = new Array(n).fill(NOISE);
  let currentCluster = 0;

  // Region query
  function getNeighbors(pointIdx: number): number[] {
    const neighbors: number[] = [];
    const pt = scaled[pointIdx].features;
    for (let i = 0; i < n; i++) {
      if (euclideanDistance(pt, scaled[i].features) <= eps) {
        neighbors.push(i);
      }
    }
    return neighbors;
  }

  for (let i = 0; i < n; i++) {
    if (status[i] !== UNVISITED) continue;

    status[i] = VISITED;
    const neighbors = getNeighbors(i);

    if (neighbors.length < minSamples) {
      clusterAssignment[i] = NOISE;
    } else {
      clusterAssignment[i] = currentCluster;
      const seedQueue = [...neighbors];

      let qIdx = 0;
      while (qIdx < seedQueue.length) {
        const currentPt = seedQueue[qIdx++];

        if (status[currentPt] === UNVISITED) {
          status[currentPt] = VISITED;
          const currentNeighbors = getNeighbors(currentPt);
          if (currentNeighbors.length >= minSamples) {
            for (const neighbor of currentNeighbors) {
              if (!seedQueue.includes(neighbor)) {
                seedQueue.push(neighbor);
              }
            }
          }
        }

        if (clusterAssignment[currentPt] === NOISE || clusterAssignment[currentPt] === undefined) {
          clusterAssignment[currentPt] = currentCluster;
        }
      }

      currentCluster++;
    }
  }

  // Count clusters and noise
  const clusterCounts: Record<number, number> = {};
  let noiseCount = 0;
  let hotspotsCount = 0;

  for (let i = 0; i < n; i++) {
    const cl = clusterAssignment[i];
    clusterCounts[cl] = (clusterCounts[cl] || 0) + 1;
    if (cl === NOISE) {
      noiseCount++;
    }
  }

  // Check which clusters are congestion hotspots (avg speed < 30 & density > 60)
  for (let c = 0; c < currentCluster; c++) {
    const pts = records.filter((_, idx) => clusterAssignment[idx] === c);
    if (pts.length > 0) {
      const avgSpd = pts.reduce((s, p) => s + p.speed, 0) / pts.length;
      const avgDen = pts.reduce((s, p) => s + p.traffic_density, 0) / pts.length;
      if (avgSpd < 35 && avgDen > 55) {
        hotspotsCount++;
      }
    }
  }

  // Calculate metrics on non-noise clusters
  let silhouette = 0;
  let daviesBouldin = 0;
  if (currentCluster > 1) {
    const nonNoiseIndices = scaled.map((_, i) => i).filter(i => clusterAssignment[i] !== NOISE);
    if (nonNoiseIndices.length > 10) {
      const subScaled = nonNoiseIndices.map(i => scaled[i]);
      const subAssignments = nonNoiseIndices.map(i => clusterAssignment[i]);
      silhouette = calculateSilhouetteScore(subScaled, subAssignments, currentCluster);
      
      // Calculate centroids for DB
      const subCentroids: number[][] = Array.from({ length: currentCluster }, () => [0, 0, 0]);
      const subCounts = new Array(currentCluster).fill(0);
      for (let i = 0; i < subScaled.length; i++) {
        const c = subAssignments[i];
        subCounts[c]++;
        subCentroids[c][0] += subScaled[i].features[0];
        subCentroids[c][1] += subScaled[i].features[1];
        subCentroids[c][2] += subScaled[i].features[2];
      }
      for (let c = 0; c < currentCluster; c++) {
        if (subCounts[c] > 0) {
          subCentroids[c][0] /= subCounts[c];
          subCentroids[c][1] /= subCounts[c];
          subCentroids[c][2] /= subCounts[c];
        }
      }
      daviesBouldin = calculateDaviesBouldin(subScaled, subAssignments, subCentroids, currentCluster);
    }
  }

  const updatedRecords = records.map((rec, idx) => ({
    ...rec,
    dbscan_cluster: clusterAssignment[idx],
    is_outlier: clusterAssignment[idx] === NOISE
  }));

  return {
    records: updatedRecords,
    result: {
      eps,
      minSamples,
      totalClusters: currentCluster,
      noiseCount,
      hotspotsCount,
      silhouetteScore: Number(silhouette.toFixed(3)),
      daviesBouldinIndex: Number(daviesBouldin.toFixed(3)),
      clusterCounts
    }
  };
}

// Compute Silhouette Score
function calculateSilhouetteScore(
  points: ScaledPoint[],
  assignments: number[],
  k: number
): number {
  if (k <= 1 || points.length <= k) return 0;

  const n = points.length;
  let totalScore = 0;
  let scoredPoints = 0;

  // Sample up to 100 points for performance
  const step = Math.max(1, Math.floor(n / 100));

  for (let i = 0; i < n; i += step) {
    const myCluster = assignments[i];
    const myPt = points[i].features;

    // Intra-cluster distance a(i)
    let intraSum = 0;
    let intraCount = 0;
    const interSums = new Array(k).fill(0);
    const interCounts = new Array(k).fill(0);

    for (let j = 0; j < n; j++) {
      if (i === j) continue;
      const otherCluster = assignments[j];
      const dist = euclideanDistance(myPt, points[j].features);

      if (otherCluster === myCluster) {
        intraSum += dist;
        intraCount++;
      } else if (otherCluster >= 0 && otherCluster < k) {
        interSums[otherCluster] += dist;
        interCounts[otherCluster]++;
      }
    }

    if (intraCount === 0) continue;
    const a_i = intraSum / intraCount;

    // Inter-cluster distance b(i) = min over other clusters
    let b_i = Infinity;
    for (let c = 0; c < k; c++) {
      if (c === myCluster || interCounts[c] === 0) continue;
      const avgDist = interSums[c] / interCounts[c];
      if (avgDist < b_i) b_i = avgDist;
    }

    if (b_i === Infinity) continue;

    const max_ab = Math.max(a_i, b_i);
    if (max_ab > 0) {
      const s_i = (b_i - a_i) / max_ab;
      totalScore += s_i;
      scoredPoints++;
    }
  }

  return scoredPoints > 0 ? totalScore / scoredPoints : 0;
}

// Compute Davies-Bouldin Index
function calculateDaviesBouldin(
  points: ScaledPoint[],
  assignments: number[],
  centroids: number[][],
  k: number
): number {
  if (k <= 1 || centroids.length < k) return 0;

  // Average distance within cluster i (s_i)
  const s = new Array(k).fill(0);
  const counts = new Array(k).fill(0);

  for (let i = 0; i < points.length; i++) {
    const c = assignments[i];
    if (c >= 0 && c < k) {
      const d = euclideanDistance(points[i].features, centroids[c]);
      s[c] += d;
      counts[c]++;
    }
  }

  for (let c = 0; c < k; c++) {
    s[c] = counts[c] > 0 ? s[c] / counts[c] : 0;
  }

  // Calculate R_ij = (s_i + s_j) / d(c_i, c_j)
  let dbSum = 0;
  let validK = 0;

  for (let i = 0; i < k; i++) {
    if (counts[i] === 0) continue;
    let maxR = 0;
    for (let j = 0; j < k; j++) {
      if (i === j || counts[j] === 0) continue;
      const centroidDist = euclideanDistance(centroids[i], centroids[j]);
      if (centroidDist > 0.0001) {
        const r_ij = (s[i] + s[j]) / centroidDist;
        if (r_ij > maxR) maxR = r_ij;
      }
    }
    dbSum += maxR;
    validK++;
  }

  return validK > 0 ? dbSum / validK : 0;
}

// Calculate Elbow Curve for K=2 to 8
function calculateElbowCurve(scaled: ScaledPoint[]): { k: number; inertia: number }[] {
  const curve: { k: number; inertia: number }[] = [];
  const n = scaled.length;

  for (let k = 2; k <= 8; k++) {
    // Quick K-Means run
    const centroids: number[][] = [];
    for (let c = 0; c < k; c++) {
      const sampleIdx = Math.floor((c * n) / k);
      centroids.push([...scaled[sampleIdx].features]);
    }

    const assignments = new Array(n).fill(0);
    for (let iter = 0; iter < 10; iter++) {
      for (let i = 0; i < n; i++) {
        let minDist = Infinity;
        let best = 0;
        for (let c = 0; c < k; c++) {
          const d = euclideanDistance(scaled[i].features, centroids[c]);
          if (d < minDist) {
            minDist = d;
            best = c;
          }
        }
        assignments[i] = best;
      }

      const counts = new Array(k).fill(0);
      const sums: number[][] = Array.from({ length: k }, () => [0, 0, 0]);
      for (let i = 0; i < n; i++) {
        const c = assignments[i];
        counts[c]++;
        sums[c][0] += scaled[i].features[0];
        sums[c][1] += scaled[i].features[1];
        sums[c][2] += scaled[i].features[2];
      }
      for (let c = 0; c < k; c++) {
        if (counts[c] > 0) {
          centroids[c][0] = sums[c][0] / counts[c];
          centroids[c][1] = sums[c][1] / counts[c];
          centroids[c][2] = sums[c][2] / counts[c];
        }
      }
    }

    let inertia = 0;
    for (let i = 0; i < n; i++) {
      const c = assignments[i];
      const d = euclideanDistance(scaled[i].features, centroids[c]);
      inertia += d * d;
    }

    curve.push({ k, inertia: Number(inertia.toFixed(2)) });
  }

  return curve;
}
