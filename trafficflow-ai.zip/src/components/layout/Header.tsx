/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Activity, Download, RotateCcw, Menu, X, Cpu } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  totalRecords: number;
  onReset: () => void;
  onExport: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  totalRecords,
  onReset,
  onExport,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 lg:px-8 py-3.5 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      {/* Zone 1: Brand & Current View */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 lg:hidden"
          aria-label="Toggle Navigation Menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold text-base">
            TF
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-100 tracking-tight text-base lg:text-lg">
                TrafficFlow AI
              </span>
              <span className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                ML Analysis Active
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden md:block">
              Traffic Flow Pattern Clustering · K-Means &amp; DBSCAN
            </p>
          </div>
        </div>
      </div>

      {/* Zone 2: Engine Status & Telemetry Context */}
      <div className="hidden xl:flex items-center gap-4 text-xs text-slate-400">
        <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-md border border-slate-800/80">
          <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          <span>Engine: <span className="text-slate-200 font-mono">In-Memory Scikit Simulator</span></span>
        </div>
        <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-md border border-slate-800/80">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span>Active Dataset: <span className="text-slate-200 font-mono tabular-nums">{totalRecords} records</span></span>
        </div>
      </div>

      {/* Zone 3: Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onReset}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700/60 transition-colors"
          title="Reset dataset to default calibrated samples"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline">Reset Data</span>
        </button>

        <button
          onClick={onExport}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-lg shadow-sm shadow-cyan-600/30 transition-all cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Report</span>
        </button>
      </div>
    </header>
  );
};
