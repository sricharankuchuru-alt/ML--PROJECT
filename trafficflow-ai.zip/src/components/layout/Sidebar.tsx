/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  Database,
  PieChart,
  Radio,
  GitCompare,
  MapPin,
  Sparkles,
  GraduationCap,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  kValue: number;
  dbscanClusters: number;
}

export const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, desc: 'Overview & Key Metrics' },
  { id: 'data', label: 'Traffic Data', icon: Database, desc: 'Dataset & Preprocessing' },
  { id: 'kmeans', label: 'K-Means', icon: PieChart, desc: 'Centroid Partitioning' },
  { id: 'dbscan', label: 'DBSCAN', icon: Radio, desc: 'Density & Outliers' },
  { id: 'comparison', label: 'Model Comparison', icon: GitCompare, desc: 'K-Means vs DBSCAN' },
  { id: 'map', label: 'Traffic Map', icon: MapPin, desc: 'Spatial GIS Clusters' },
  { id: 'insights', label: 'Insights', icon: Sparkles, desc: 'AI Analytics & Actions' },
  { id: 'about', label: 'About Project', icon: GraduationCap, desc: 'Problem, Tech & Viva' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  mobileOpen,
  setMobileOpen,
  kValue,
  dbscanClusters,
}) => {
  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-md shadow-cyan-500/20 text-white font-bold text-sm">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-wide">
                TrafficFlow AI
              </h1>
              <p className="text-[11px] text-cyan-400 font-medium">ML Cluster Studio</p>
            </div>
          </div>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Clustering Pipeline
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all group relative ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/10 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <div className="flex-1 text-left truncate">
                  <div className="truncate font-semibold">{item.label}</div>
                  <div className="text-[10px] text-slate-400 truncate group-hover:text-slate-300">
                    {item.desc}
                  </div>
                </div>

                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400" />
                )}
              </button>
            );
          })}
        </div>

        {/* Model quick status box */}
        <div className="p-3 m-3 rounded-lg bg-slate-950/70 border border-slate-800/90 text-xs">
          <div className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider mb-2">
            Active Parameters
          </div>
          <div className="space-y-1.5 font-mono text-[11px]">
            <div className="flex items-center justify-between text-slate-300">
              <span className="text-slate-400 font-sans">K-Means K:</span>
              <span className="text-cyan-400 font-bold">{kValue} Clusters</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span className="text-slate-400 font-sans">DBSCAN Clusters:</span>
              <span className="text-emerald-400 font-bold">{dbscanClusters} Dense</span>
            </div>
          </div>
          <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span>FastAPI Bridge</span>
            <span className="text-amber-400 font-mono">Ready (Client Sim)</span>
          </div>
        </div>

        {/* Academic Project Viva info */}
        <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 bg-slate-950/40">
          <p className="font-medium text-slate-300 truncate">Final Year B.Tech Project</p>
          <p className="text-[10px] text-slate-400 truncate">ML / Pattern Recognition</p>
        </div>
      </aside>
    </>
  );
};
