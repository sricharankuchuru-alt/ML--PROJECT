/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-auto py-5 px-6 border-t border-slate-800 bg-slate-950/80 text-xs text-slate-400">
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-300">TrafficFlow AI</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Machine Learning Project</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span className="text-cyan-400 font-mono text-[11px]">K-Means + DBSCAN</span>
        </div>

        <div className="flex items-center gap-4 text-slate-400 text-[11px]">
          <span>Unsupervised Traffic Analytics</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Python Scikit-Learn Architecture</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span className="text-slate-400">Demo / Sample Analysis</span>
        </div>
      </div>
    </footer>
  );
};
