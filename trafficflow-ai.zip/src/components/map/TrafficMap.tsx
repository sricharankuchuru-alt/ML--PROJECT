/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import {
  MapPin,
  Layers,
  Filter,
  Eye,
  Info,
  Car,
  Gauge,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { TrafficRecord, TrafficStatus } from '../../types/traffic';
import { CLUSTER_COLORS, NOISE_COLOR } from '../../utils/mlAlgorithms';

interface TrafficMapProps {
  records: TrafficRecord[];
  kValue: number;
}

export const TrafficMap: React.FC<TrafficMapProps> = ({ records, kValue }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);

  const [colorMode, setColorMode] = useState<'status' | 'kmeans' | 'dbscan'>('status');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedRoad, setSelectedRoad] = useState<string>('ALL');
  const [selectedKMeans, setSelectedKMeans] = useState<string>('ALL');
  const [selectedDBSCAN, setSelectedDBSCAN] = useState<string>('ALL');

  // Distinct roads for dropdown
  const uniqueRoads = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.road_segment))).sort();
  }, [records]);

  // Filtered records for map points
  const mapRecords = useMemo(() => {
    return records.filter((r) => {
      const matchStatus = selectedStatus === 'ALL' || r.traffic_status === selectedStatus;
      const matchRoad = selectedRoad === 'ALL' || r.road_segment === selectedRoad;
      const matchKM = selectedKMeans === 'ALL' || String(r.kmeans_cluster) === selectedKMeans;
      const matchDB =
        selectedDBSCAN === 'ALL' ||
        (selectedDBSCAN === 'noise' && r.dbscan_cluster === -1) ||
        String(r.dbscan_cluster) === selectedDBSCAN;

      return matchStatus && matchRoad && matchKM && matchDB;
    });
  }, [records, selectedStatus, selectedRoad, selectedKMeans, selectedDBSCAN]);

  // Color resolver helper
  const getMarkerColor = (record: TrafficRecord): string => {
    // If it's an outlier and in dbscan view, or in general, flag noise
    if (colorMode === 'dbscan') {
      if (record.dbscan_cluster === -1) return NOISE_COLOR;
      return CLUSTER_COLORS[(record.dbscan_cluster ?? 0) % CLUSTER_COLORS.length];
    }

    if (colorMode === 'kmeans') {
      return CLUSTER_COLORS[(record.kmeans_cluster ?? 0) % CLUSTER_COLORS.length];
    }

    // Default: Traffic Status Color
    if (record.dbscan_cluster === -1 && record.is_outlier) {
      return NOISE_COLOR; // Outlier override
    }

    switch (record.traffic_status) {
      case 'Free Flow':
        return '#10B981'; // Green
      case 'Moderate':
        return '#38BDF8'; // Cyan / Light Blue
      case 'Heavy':
        return '#F59E0B'; // Amber
      case 'Congested':
        return '#EF4444'; // Red
      default:
        return '#64748b';
    }
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Default center around San Francisco metropolitan road network
      const map = L.map(mapContainerRef.current, {
        center: [37.7749, -122.4194],
        zoom: 12,
        zoomControl: true,
      });

      // CartoDB Dark Matter tile layer for slick dark engineering aesthetics
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(map);

      const layerGroup = L.layerGroup().addTo(map);
      layerGroupRef.current = layerGroup;
      mapInstanceRef.current = map;

      // Invalidate size after layout settles
      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 200);
    }

    return () => {
      // Cleanup on unmount
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update map markers when data, filters, or color mode change
  useEffect(() => {
    if (!layerGroupRef.current || !mapInstanceRef.current) return;

    layerGroupRef.current.clearLayers();

    const bounds: [number, number][] = [];

    mapRecords.forEach((r) => {
      if (!r.latitude || !r.longitude) return;

      bounds.push([r.latitude, r.longitude]);
      const color = getMarkerColor(r);
      const isNoise = r.dbscan_cluster === -1;

      // Circle marker
      const marker = L.circleMarker([r.latitude, r.longitude], {
        radius: isNoise ? 8 : 6,
        fillColor: color,
        color: isNoise ? '#FFFFFF' : '#0f172a',
        weight: isNoise ? 2 : 1.5,
        opacity: 0.95,
        fillOpacity: 0.85,
      });

      // Custom sleek popup content
      const popupHtml = `
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; padding: 4px; min-width: 190px;">
          <div style="font-weight: 700; color: #f8fafc; font-size: 13px; margin-bottom: 2px;">
            ${r.road_segment}
          </div>
          <div style="font-size: 10px; color: #94a3b8; margin-bottom: 8px;">
            ${r.record_id} · ${r.timestamp}
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; font-size: 11px; margin-bottom: 8px;">
            <div style="background: rgba(15, 23, 42, 0.6); padding: 4px 6px; border-radius: 4px; border: 1px solid #1e293b;">
              <span style="color: #64748b; font-size: 9px; display: block;">SPEED</span>
              <strong style="color: #38bdf8;">${r.speed} km/h</strong>
            </div>
            <div style="background: rgba(15, 23, 42, 0.6); padding: 4px 6px; border-radius: 4px; border: 1px solid #1e293b;">
              <span style="color: #64748b; font-size: 9px; display: block;">DENSITY</span>
              <strong style="color: #fbbf24;">${r.traffic_density} veh/km</strong>
            </div>
            <div style="background: rgba(15, 23, 42, 0.6); padding: 4px 6px; border-radius: 4px; border: 1px solid #1e293b;">
              <span style="color: #64748b; font-size: 9px; display: block;">VOLUME</span>
              <strong style="color: #f8fafc;">${r.traffic_volume} veh/h</strong>
            </div>
            <div style="background: rgba(15, 23, 42, 0.6); padding: 4px 6px; border-radius: 4px; border: 1px solid #1e293b;">
              <span style="color: #64748b; font-size: 9px; display: block;">WEATHER</span>
              <strong style="color: #94a3b8;">${r.weather}</strong>
            </div>
          </div>

          <div style="border-top: 1px solid #334155; padding-top: 6px; font-size: 11px; display: flex; flex-direction: column; gap: 3px;">
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #94a3b8;">Traffic Status:</span>
              <strong style="color: ${color};">${r.traffic_status}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #94a3b8;">K-Means Cluster:</span>
              <span style="color: #38bdf8; font-family: monospace;">Cluster ${r.kmeans_cluster ?? 0}</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #94a3b8;">DBSCAN Cluster:</span>
              <span style="color: ${isNoise ? '#c084fc' : '#34d399'}; font-family: monospace;">
                ${isNoise ? 'Noise Outlier (-1)' : `Cluster ${r.dbscan_cluster ?? 0}`}
              </span>
            </div>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);
      layerGroupRef.current?.addLayer(marker);
    });

    // Fit map bounds if points exist
    if (bounds.length > 0 && mapInstanceRef.current) {
      try {
        mapInstanceRef.current.fitBounds(L.latLngBounds(bounds), {
          padding: [30, 30],
          maxZoom: 14,
        });
      } catch (err) {
        // Safe fallback
      }
    }
  }, [mapRecords, colorMode]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>Spatial Geographic Intelligence</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Interactive GIS Traffic Map
            </h2>
            <p className="text-xs lg:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Geospatial distribution of traffic flow conditions, arterial bottlenecks, and detected anomalous clusters across the urban road corridor network.
            </p>
          </div>

          {/* Color Display Mode Toggles */}
          <div className="flex items-center p-1 bg-slate-950/80 rounded-xl border border-slate-800 text-xs shrink-0">
            <button
              onClick={() => setColorMode('status')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                colorMode === 'status'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Traffic Status
            </button>
            <button
              onClick={() => setColorMode('kmeans')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                colorMode === 'kmeans'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              K-Means Clusters
            </button>
            <button
              onClick={() => setColorMode('dbscan')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                colorMode === 'dbscan'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              DBSCAN (Noise &amp; Dense)
            </button>
          </div>
        </div>
      </div>

      {/* Map Control and Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-3">
        <div>
          <label className="block text-[11px] text-slate-400 mb-1">Traffic Status Filter</label>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="ALL">All Statuses ({records.length})</option>
            <option value="Free Flow">Free Flow (Green)</option>
            <option value="Moderate">Moderate (Cyan)</option>
            <option value="Heavy">Heavy Flow (Amber)</option>
            <option value="Congested">Congested (Red)</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] text-slate-400 mb-1">Road Segment Corridor</label>
          <select
            value={selectedRoad}
            onChange={(e) => setSelectedRoad(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500 truncate"
          >
            <option value="ALL">All Road Corridors</option>
            {uniqueRoads.map((road) => (
              <option key={road} value={road}>
                {road}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] text-slate-400 mb-1">K-Means Cluster</label>
          <select
            value={selectedKMeans}
            onChange={(e) => setSelectedKMeans(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="ALL">All K-Means Clusters</option>
            {Array.from({ length: kValue }).map((_, idx) => (
              <option key={idx} value={String(idx)}>
                Cluster {idx}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] text-slate-400 mb-1">DBSCAN Filter</label>
          <select
            value={selectedDBSCAN}
            onChange={(e) => setSelectedDBSCAN(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="ALL">All DBSCAN Records</option>
            <option value="noise">Noise Outliers Only (Purple)</option>
            <option value="0">Cluster 0 (Dense)</option>
            <option value="1">Cluster 1 (Dense)</option>
            <option value="2">Cluster 2 (Dense)</option>
          </select>
        </div>
      </div>

      {/* Map View Container with Floating Legend */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-xl bg-slate-950">
        <div ref={mapContainerRef} className="w-full h-[540px] z-10" />

        {/* Floating Map Legend */}
        <div className="absolute bottom-4 right-4 z-20 p-3.5 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-800 shadow-xl text-xs space-y-2 max-w-xs">
          <div className="flex items-center justify-between text-slate-300 font-semibold border-b border-slate-800 pb-1.5">
            <span>Map Legend ({colorMode.toUpperCase()})</span>
            <span className="text-[10px] font-mono text-cyan-400">{mapRecords.length} visible</span>
          </div>

          {colorMode === 'status' && (
            <div className="space-y-1.5 text-[11px]">
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
                <span>Free Flow (Speed &ge; 60 km/h)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-full bg-cyan-400 shrink-0" />
                <span>Moderate Traffic (40–59 km/h)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-full bg-amber-400 shrink-0" />
                <span>Heavy Flow (25–39 km/h)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-full bg-rose-500 shrink-0" />
                <span>Congested Bottleneck (&lt; 25 km/h)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-full bg-purple-500 ring-2 ring-white shrink-0" />
                <span>DBSCAN Noise Outlier (Incident)</span>
              </div>
            </div>
          )}

          {colorMode === 'kmeans' && (
            <div className="space-y-1.5 text-[11px]">
              {Array.from({ length: kValue }).map((_, i) => (
                <div key={i} className="flex items-center gap-2 text-slate-300">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: CLUSTER_COLORS[i % CLUSTER_COLORS.length] }}
                  />
                  <span>K-Means Cluster {i}</span>
                </div>
              ))}
            </div>
          )}

          {colorMode === 'dbscan' && (
            <div className="space-y-1.5 text-[11px]">
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
                <span>Dense Normal / Congestion Clusters</span>
              </div>
              <div className="flex items-center gap-2 text-purple-300">
                <span className="w-3 h-3 rounded-full bg-purple-500 ring-2 ring-white shrink-0" />
                <span className="font-semibold">DBSCAN Noise (-1 Outlier)</span>
              </div>
            </div>
          )}

          <div className="pt-1.5 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
            <span>Click marker for details</span>
            <span>OpenStreetMap</span>
          </div>
        </div>
      </div>
    </div>
  );
};
