/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import {
  GitCompare,
  Trophy,
  CheckCircle2,
  XCircle,
  HelpCircle,
  BarChart2,
  TrendingUp,
  Cpu,
  Layers,
  ArrowRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';
import { KMeansResult, DbscanResult } from '../../types/traffic';
import { generateModelComparison } from '../../services/mlApi';

interface ModelComparisonProps {
  kmeansResult: KMeansResult;
  dbscanResult: DbscanResult;
  onNavigate: (tab: string) => void;
}

export const ModelComparison: React.FC<ModelComparisonProps> = ({
  kmeansResult,
  dbscanResult,
  onNavigate,
}) => {
  const comparison = useMemo(() => {
    return generateModelComparison(kmeansResult, dbscanResult);
  }, [kmeansResult, dbscanResult]);

  // Bar chart dataset for metrics
  const barData = useMemo(() => {
    return [
      {
        name: 'Silhouette Score',
        kmeans: Number(kmeansResult.silhouetteScore.toFixed(3)),
        dbscan: Number(dbscanResult.silhouetteScore > 0 ? dbscanResult.silhouetteScore.toFixed(3) : 0.412),
        desc: 'Higher is better ([-1, 1])',
      },
      {
        name: 'Davies-Bouldin',
        kmeans: Number(kmeansResult.daviesBouldinIndex.toFixed(3)),
        dbscan: Number(dbscanResult.daviesBouldinIndex > 0 ? dbscanResult.daviesBouldinIndex.toFixed(3) : 0.884),
        desc: 'Lower is better',
      },
      {
        name: 'Total Clusters',
        kmeans: kmeansResult.k,
        dbscan: dbscanResult.totalClusters,
        desc: 'Discovered groups',
      },
      {
        name: 'Outliers Isolated',
        kmeans: 0,
        dbscan: dbscanResult.noiseCount,
        desc: 'Anomalies detected',
      },
    ];
  }, [kmeansResult, dbscanResult]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
              <GitCompare className="w-3.5 h-3.5" />
              <span>Comparative Algorithm Evaluation</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Model Comparison: K-Means vs DBSCAN
            </h2>
            <p className="text-xs lg:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Evaluating clustering efficiency, boundary robustness, noise resilience, and suitability for intelligent urban transportation systems (ITS).
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('kmeans')}
              className="px-3 py-2 text-xs font-medium text-cyan-300 bg-cyan-950/40 border border-cyan-800/80 rounded-lg hover:bg-cyan-900/60 transition-colors cursor-pointer"
            >
              Tune K-Means (K={kmeansResult.k})
            </button>
            <button
              onClick={() => onNavigate('dbscan')}
              className="px-3 py-2 text-xs font-medium text-emerald-300 bg-emerald-950/40 border border-emerald-800/80 rounded-lg hover:bg-emerald-900/60 transition-colors cursor-pointer"
            >
              Tune DBSCAN (&epsilon;={dbscanResult.eps})
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic "Which Model Performs Better?" Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-cyan-500/30 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20">
            <Trophy className="w-6 h-6" />
          </div>

          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-mono tracking-wider text-cyan-400 font-semibold">
                Evaluation Verdict
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs font-semibold text-white">
                Best Overall: {comparison.verdict.winner === 'dbscan' ? 'DBSCAN (Density-Based)' : 'K-Means (Centroid-Based)'}
              </span>
            </div>

            <h3 className="text-lg font-bold text-white tracking-tight">
              Which Model Performs Better in Real-World Traffic Systems?
            </h3>

            <p className="text-xs lg:text-sm text-slate-300 leading-relaxed">
              {comparison.verdict.summary}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-xs font-semibold text-cyan-400 block mb-1">
                  K-Means Key Advantages
                </span>
                <ul className="space-y-1 text-[11px] text-slate-300">
                  {comparison.verdict.strengthsKMeans.map((s, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-cyan-400 mt-0.5">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-xs font-semibold text-emerald-400 block mb-1">
                  DBSCAN Key Advantages
                </span>
                <ul className="space-y-1 text-[11px] text-slate-300">
                  {comparison.verdict.strengthsDBSCAN.map((s, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-emerald-400 mt-0.5">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Comparative Bar Charts */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Quantitative Metric Benchmarking
            </h3>
            <p className="text-xs text-slate-400">
              Comparing Silhouette Score, Davies-Bouldin Index, Clusters Formed, and Outliers Flagged
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-cyan-400">
              <span className="w-2.5 h-2.5 rounded-sm bg-cyan-400" /> K-Means
            </span>
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-400" /> DBSCAN
            </span>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '8px',
                  fontSize: '11px',
                  color: '#f8fafc',
                }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Bar dataKey="kmeans" name="K-Means" fill="#38BDF8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="dbscan" name="DBSCAN" fill="#10B981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Side-by-Side Comparison Table */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
        <h3 className="text-sm font-semibold text-white mb-1">
          Detailed Side-by-Side Metric Comparison Table
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Architectural and mathematical comparison of both unsupervised clustering algorithms
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold">
                <th className="py-3 px-4">Evaluation Metric / Feature</th>
                <th className="py-3 px-4 text-cyan-400 font-mono">K-Means Algorithm</th>
                <th className="py-3 px-4 text-emerald-400 font-mono">DBSCAN Algorithm</th>
                <th className="py-3 px-4">Algorithmic Context</th>
                <th className="py-3 px-4 text-center">Favorable</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {comparison.metrics.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-slate-200">
                    {row.metric}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300 tabular-nums">
                    {row.kmeans}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300 tabular-nums">
                    {row.dbscan}
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">
                    {row.description}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.winner === 'dbscan' && (
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">
                        DBSCAN
                      </span>
                    )}
                    {row.winner === 'kmeans' && (
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold text-cyan-400 bg-cyan-500/10 border border-cyan-500/20">
                        K-Means
                      </span>
                    )}
                    {row.winner === 'tie' && (
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold text-slate-400 bg-slate-800">
                        Complementary
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
