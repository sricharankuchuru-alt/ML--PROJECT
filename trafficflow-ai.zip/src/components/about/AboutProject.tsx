/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  GraduationCap,
  Target,
  Layers,
  Code2,
  Workflow,
  HelpCircle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  FileCode,
  Terminal,
} from 'lucide-react';

export const AboutProject: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const vivaQuestions = [
    {
      q: 'Why use unsupervised learning instead of supervised learning for traffic flow analysis?',
      a: 'In real-world municipal road networks, there are no predefined ground-truth labels classifying every second of traffic as "Heavy" or "Congested" across millions of sensors. Unsupervised clustering allows algorithms to discover intrinsic patterns, naturally grouping similar speed-density-volume profiles without human labeling bias.',
    },
    {
      q: 'How did you determine the optimal number of clusters (K) in K-Means?',
      a: 'We applied the Elbow Method alongside the Silhouette Coefficient. In our inertia curve, an "elbow" bend occurs around K=4, which also coincides with a high Silhouette score (>0.45). Operationally, K=4 maps cleanly to four real-world traffic regimes: Free Flow, Moderate, Heavy, and Congested.',
    },
    {
      q: 'What makes DBSCAN particularly well-suited for traffic sensor datasets?',
      a: 'Standard K-Means forces every data point into its nearest centroid, which means severe accidents or detector loop malfunctions severely skew the cluster center. DBSCAN separates points based on density reachability and labels isolated anomalies as noise (-1), preventing them from distorting normal traffic patterns.',
    },
    {
      q: 'What distance metric is used and why was feature normalization necessary?',
      a: 'We use Euclidean distance in 3-dimensional space: [Speed, Volume, Density]. Since volume ranges in thousands (e.g., 2,400 veh/h) while density is below 100 veh/km and speed is 0–100 km/h, raw Euclidean distance would be 99% dominated by volume. Min-Max normalization scales each dimension to [0, 1] so every feature contributes equally.',
    },
    {
      q: 'How can this React frontend connect to our real Scikit-Learn / FastAPI backend?',
      a: 'The application contains a dedicated modular service layer in `src/services/mlApi.ts`. The endpoints (`/api/upload`, `/api/preprocess`, `/api/kmeans`, `/api/dbscan`, `/api/compare`) can be toggled to point directly to a running FastAPI server (`http://localhost:8000/api`) with matching Pydantic response schemas.',
    },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
          <GraduationCap className="w-4 h-4" />
          <span>Final Year Engineering Machine Learning Project</span>
        </div>
        <h2 className="text-2xl lg:text-3xl font-bold text-white tracking-tight">
          Traffic Flow Pattern Clustering Using K-Means and DBSCAN
        </h2>
        <p className="text-xs lg:text-sm text-slate-300 mt-2 leading-relaxed">
          An unsupervised learning application for automated categorization of urban arterial traffic flow regimes, identification of recurring congestion bottlenecks, and isolation of sensor anomalies.
        </p>
      </div>

      {/* Problem Statement & Objectives Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-3">
          <div className="flex items-center gap-2 text-rose-400 font-semibold text-sm">
            <Target className="w-4 h-4" />
            <span>Problem Statement</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Urban traffic patterns fluctuate dynamically across road segments and temporal windows. Manual monitoring and fixed static signal timers cannot keep pace with the massive volume of high-frequency inductive loops, radar sensors, and GPS telemetry. There is a pressing need for automated unsupervised systems to cluster multi-dimensional flow states and isolate non-recurring bottlenecks.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
            <Target className="w-4 h-4" />
            <span>Project Objectives</span>
          </div>
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">•</span>
              <span>Collect and preprocess multi-attribute traffic flow data (Speed, Volume, Density).</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">•</span>
              <span>Implement K-Means clustering to partition observations into operational regimes.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">•</span>
              <span>Implement DBSCAN clustering to discover arbitrary cluster shapes and detect noise.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">•</span>
              <span>Evaluate and benchmark both models via Silhouette Score and Davies-Bouldin Index.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">•</span>
              <span>Geospatially map clusters on an interactive OpenStreetMap GIS interface.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Project Workflow Diagram */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-4">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
          <Workflow className="w-4 h-4" />
          <span>End-to-End Machine Learning Pipeline</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-7 gap-2 text-center text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-white">1. Data Ingestion</span>
            <span className="text-[10px] text-slate-400 mt-1">Loop sensors &amp; CSV</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-white">2. Preprocessing</span>
            <span className="text-[10px] text-slate-400 mt-1">Imputation &amp; cleaning</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-white">3. Feature Scale</span>
            <span className="text-[10px] text-slate-400 mt-1">MinMaxScaler [0,1]</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-cyan-400">4. K-Means / DBSCAN</span>
            <span className="text-[10px] text-slate-400 mt-1">Unsupervised run</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-white">5. Evaluation</span>
            <span className="text-[10px] text-slate-400 mt-1">Silhouette &amp; DB Index</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-white">6. Visualization</span>
            <span className="text-[10px] text-slate-400 mt-1">Scatter &amp; GIS Map</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
            <span className="font-semibold text-emerald-400">7. Traffic Action</span>
            <span className="text-[10px] text-slate-400 mt-1">Signal timing plans</span>
          </div>
        </div>
      </div>

      {/* Technology Stack Grid */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-3">
        <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
          <Code2 className="w-4 h-4" />
          <span>Technology &amp; Libraries Used</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Python 3.11</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Core ML Backend</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Scikit-learn</span>
            <p className="text-[10px] text-slate-400 mt-0.5">KMeans &amp; DBSCAN</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Pandas &amp; NumPy</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Feature Matrix Math</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Matplotlib / Seaborn</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Statistical Plots</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">React 19 + TypeScript</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Interactive Dashboard</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Tailwind CSS</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Modern Dark UI</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Leaflet / OpenStreetMap</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Geospatial GIS Map</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="font-semibold text-slate-200">Recharts</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Elbow &amp; Scatter Charts</p>
          </div>
        </div>
      </div>

      {/* Scikit-Learn Python Implementation Reference (For Viva presentation) */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
            <Terminal className="w-4 h-4" />
            <span>Python Scikit-Learn Implementation Snippet</span>
          </div>
          <span className="text-[11px] font-mono text-slate-400">main.py (FastAPI ready)</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 overflow-x-auto text-[11px] font-mono text-slate-300 leading-relaxed">
          <pre>{`from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans, DBSCAN
from sklearn.metrics import silhouette_score, davies_bouldin_score

# 1. Feature matrix extraction [speed, volume, density]
X = df[['speed', 'traffic_volume', 'traffic_density']].values
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

# 2. K-Means clustering (Partitional)
kmeans = KMeans(n_clusters=4, init='k-means++', random_state=42)
df['kmeans_cluster'] = kmeans.fit_predict(X_scaled)
km_silhouette = silhouette_score(X_scaled, df['kmeans_cluster'])
km_db_index = davies_bouldin_score(X_scaled, df['kmeans_cluster'])

# 3. DBSCAN clustering (Density-based with noise detection)
dbscan = DBSCAN(eps=0.28, min_samples=4, metric='euclidean')
df['dbscan_cluster'] = dbscan.fit_predict(X_scaled)
noise_points = (df['dbscan_cluster'] == -1).sum()`}</pre>
        </div>
      </div>

      {/* Viva / Presentation Q&A Section */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-4">
        <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
          <HelpCircle className="w-4 h-4" />
          <span>Project Defense &amp; Viva Q&amp;A Cheat Sheet</span>
        </div>
        <p className="text-xs text-slate-400">
          Key questions frequently asked by academic review panels and external examiners:
        </p>

        <div className="space-y-2">
          {vivaQuestions.map((item, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-slate-800 bg-slate-950/60 overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-3.5 text-left text-xs font-semibold text-slate-200 flex items-center justify-between hover:bg-slate-800/40 transition-colors cursor-pointer"
                >
                  <span>{item.q}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-cyan-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
                {isOpen && (
                  <div className="p-3.5 pt-0 text-xs text-slate-400 leading-relaxed border-t border-slate-800/50 mt-1">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Future Scope */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md space-y-3">
        <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
          <Sparkles className="w-4 h-4" />
          <span>Future Scope &amp; Enhancements</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <strong className="text-white block mb-0.5">• Real-time GPS &amp; IoT Streaming:</strong>
            Streaming Kafka pipeline for sub-minute live sensor updates.
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <strong className="text-white block mb-0.5">• HDBSCAN &amp; OPTICS:</strong>
            Hierarchical density clustering to handle varying traffic densities across suburbs vs downtown.
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <strong className="text-white block mb-0.5">• Predictive Traffic Forecasting:</strong>
            Combining discovered cluster states with LSTM/GRU networks for ahead-of-time queue prediction.
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <strong className="text-white block mb-0.5">• Continuous Model Retraining:</strong>
            Automated MLOps scheduled retraining to account for seasonal and construction shifts.
          </div>
        </div>
      </div>
    </div>
  );
};
