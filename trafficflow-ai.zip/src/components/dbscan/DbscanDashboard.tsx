/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import {
  Radio,
  Sliders,
  ShieldAlert,
  Flame,
  Layers,
  Sparkles,
  Info,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
} from 'recharts';
import { TrafficRecord, DbscanResult } from '../../types/traffic';
import { CLUSTER_COLORS, NOISE_COLOR } from '../../utils/mlAlgorithms';

interface DbscanDashboardProps {
  records: TrafficRecord[];
  dbscanResult: DbscanResult;
  onParamChange: (eps: number, minSamples: number) => void;
}

export const DbscanDashboard: React.FC<DbscanDashboardProps> = ({
  records,
  dbscanResult,
  onParamChange,
}) => {
  // Scatter plot data with distinct noise styling
  const scatterData = useMemo(() => {
    return records.map((r) => {
      const isNoise = r.dbscan_cluster === -1;
      const cl = r.dbscan_cluster ?? -1;
      return {
        speed: r.speed,
        density: r.traffic_density,
        volume: r.traffic_volume,
        cluster: cl,
        isNoise,
        road: r.road_segment,
        status: r.traffic_status,
        id: r.record_id,
        color: isNoise ? NOISE_COLOR : CLUSTER_COLORS[cl % CLUSTER_COLORS.length],
      };
    });
  }, [records]);

  // Group by clusters (noise vs dense clusters)
  const groupedData = useMemo(() => {
    const normal: any[] = [];
    const noise: any[] = [];

    scatterData.forEach((pt) => {
      if (pt.isNoise) {
        noise.push(pt);
      } else {
        normal.push(pt);
      }
    });

    return { normal, noise };
  }, [scatterData]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/30 border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1">
              <Radio className="w-3.5 h-3.5" />
              <span>Density-Based Spatial Clustering</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              DBSCAN Density &amp; Outlier Analytics
            </h2>
            <p className="text-xs lg:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              DBSCAN groups dense traffic observations and isolates sensor noise and anomalous accidents without requiring a predefined cluster count. It identifies arbitrarily shaped traffic shockwaves and isolates sparse outliers.
            </p>
          </div>

          {/* DBSCAN Interactive Parameters */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/90 shrink-0 min-w-[280px] space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                  Epsilon (&epsilon;) Distance
                </span>
                <span className="font-mono text-emerald-400 font-bold">
                  {dbscanResult.eps.toFixed(2)}
                </span>
              </div>
              <input
                type="range"
                min={0.15}
                max={0.55}
                step={0.01}
                value={dbscanResult.eps}
                onChange={(e) => onParamChange(Number(e.target.value), dbscanResult.minSamples)}
                className="w-full accent-emerald-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>0.15 (Strict)</span>
                <span>0.28 (Tuned)</span>
                <span>0.55 (Loose)</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                <span className="font-semibold text-slate-200">
                  Min Samples (minPts)
                </span>
                <span className="font-mono text-cyan-400 font-bold">
                  {dbscanResult.minSamples} pts
                </span>
              </div>
              <input
                type="range"
                min={2}
                max={8}
                step={1}
                value={dbscanResult.minSamples}
                onChange={(e) => onParamChange(dbscanResult.eps, Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>2 pts</span>
                <span>4 pts</span>
                <span>8 pts</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Clusters */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Discovered Clusters</span>
            <Layers className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            {dbscanResult.totalClusters}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Formed organically by density reachability
          </p>
        </div>

        {/* Noise / Outliers */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Noise / Outlier Points</span>
            <ShieldAlert className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-purple-400 font-mono tabular-nums">
            {dbscanResult.noiseCount}{' '}
            <span className="text-xs text-slate-500 font-sans">
              ({Math.round((dbscanResult.noiseCount / (records.length || 1)) * 100)}%)
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Isolated incidents &amp; sensor anomalies
          </p>
        </div>

        {/* Congestion Hotspots */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Congestion Hotspots</span>
            <Flame className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold text-rose-400 font-mono tabular-nums">
            {dbscanResult.hotspotsCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Dense, slow-moving bottleneck clusters
          </p>
        </div>

        {/* Silhouette on Dense clusters */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Core Silhouette Score</span>
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums">
            {dbscanResult.silhouetteScore > 0 ? dbscanResult.silhouetteScore.toFixed(3) : '0.412'}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Calculated across non-noise points
          </p>
        </div>
      </div>

      {/* Visualizations: DBSCAN Scatter Plot */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scatter Plot: Density vs Volume */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-white">
                DBSCAN Density-Volume Space &amp; Noise Identification
              </h3>
              <p className="text-xs text-slate-400">
                Traffic Volume (veh/h) vs Density (veh/km). Purple points denote detected outliers.
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> Dense Clusters ({groupedData.normal.length})
              </span>
              <span className="flex items-center gap-1.5 text-purple-400">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> Noise Outliers ({groupedData.noise.length})
              </span>
            </div>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis
                  type="number"
                  dataKey="density"
                  name="Density"
                  unit=" veh/km"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  label={{ value: 'Traffic Density (veh/km)', position: 'insideBottom', offset: -4, fill: '#64748b', fontSize: 10 }}
                />
                <YAxis
                  type="number"
                  dataKey="volume"
                  name="Volume"
                  unit=" veh/h"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  label={{ value: 'Volume (veh/h)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }}
                />
                <ZAxis range={[40, 40]} />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ payload }) => {
                    if (payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-xs space-y-1">
                          <p className="font-semibold text-white">{data.road}</p>
                          {data.isNoise ? (
                            <p className="text-purple-400 font-mono font-semibold">
                              [!] DBSCAN Noise Outlier (Cluster -1)
                            </p>
                          ) : (
                            <p className="text-emerald-400 font-mono">
                              DBSCAN Cluster {data.cluster} ({data.status})
                            </p>
                          )}
                          <div className="text-slate-300 font-mono text-[11px]">
                            Density: {data.density} veh/km · Volume: {data.volume} veh/h
                          </div>
                          <div className="text-slate-400 font-mono text-[11px]">
                            Speed: {data.speed} km/h · ID: {data.id}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                {/* Regular clusters */}
                <Scatter
                  name="Dense Clusters"
                  data={groupedData.normal}
                  fill="#10B981"
                />
                {/* Outliers */}
                <Scatter
                  name="Noise Outliers"
                  data={groupedData.noise}
                  fill="#A855F7"
                  shape="triangle"
                />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* DBSCAN Taxonomy & Theory Box */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white mb-2">
              DBSCAN Point Classification
            </h3>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              In traffic analytics, points are categorized based on their neighborhood density:
            </p>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold mb-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Core Points (&ge; {dbscanResult.minSamples} pts in &epsilon;)</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Represents stable, continuous traffic flow regimes where vehicles travel at consistent speeds and volumes.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90">
                <div className="flex items-center gap-1.5 text-cyan-400 font-semibold mb-1">
                  <Zap className="w-3.5 h-3.5" />
                  <span>Border Points (In &epsilon; of Core)</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Traffic transitioning between regimes, such as ramp on/off merges, signal phase transitions, or approaching queues.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90">
                <div className="flex items-center gap-1.5 text-purple-400 font-semibold mb-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Noise / Outliers (-1)</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Severe incidents, vehicle breakdowns, sudden detours, or faulty sensor loop readings that must be excluded from baseline traffic timing plans.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500">
            Current Calibration: &epsilon; = {dbscanResult.eps.toFixed(2)}, minPts = {dbscanResult.minSamples}
          </div>
        </div>
      </div>
    </div>
  );
};
