/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet,
  AlertCircle,
  SlidersHorizontal,
  CloudRain,
  Sun,
  Cloud,
  Eye,
} from 'lucide-react';
import { TrafficRecord, WeatherCondition, TrafficStatus, PreprocessingStats } from '../../types/traffic';
import { parseTrafficCSV } from '../../services/mlApi';
import { CLUSTER_COLORS } from '../../utils/mlAlgorithms';

interface TrafficDataTableProps {
  records: TrafficRecord[];
  onUpdateRecords: (records: TrafficRecord[]) => void;
  onResetData: () => void;
  preprocessingStats: PreprocessingStats;
}

export const TrafficDataTable: React.FC<TrafficDataTableProps> = ({
  records,
  onUpdateRecords,
  onResetData,
  preprocessingStats,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [weatherFilter, setWeatherFilter] = useState('ALL');
  const [roadFilter, setRoadFilter] = useState('ALL');
  const [sortField, setSortField] = useState<keyof TrafficRecord>('record_id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [dragActive, setDragActive] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Distinct road segments for filter dropdown
  const uniqueRoads = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.road_segment))).sort();
  }, [records]);

  // Filtering and sorting
  const filteredAndSortedRecords = useMemo(() => {
    return records
      .filter((r) => {
        const matchesSearch =
          r.record_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          r.road_segment.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesStatus = statusFilter === 'ALL' || r.traffic_status === statusFilter;
        const matchesWeather = weatherFilter === 'ALL' || r.weather === weatherFilter;
        const matchesRoad = roadFilter === 'ALL' || r.road_segment === roadFilter;

        return matchesSearch && matchesStatus && matchesWeather && matchesRoad;
      })
      .sort((a, b) => {
        let valA = a[sortField];
        let valB = b[sortField];

        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortDirection === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortDirection === 'asc' ? valA - valB : valB - valA;
        }
        return 0;
      });
  }, [records, searchTerm, statusFilter, weatherFilter, roadFilter, sortField, sortDirection]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredAndSortedRecords.length / pageSize) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredAndSortedRecords.slice(start, start + pageSize);
  }, [filteredAndSortedRecords, currentPage, pageSize]);

  const handleSort = (field: keyof TrafficRecord) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // CSV File Handler
  const handleFile = (file: File) => {
    setUploadError(null);
    setUploadSuccess(null);

    if (!file.name.endsWith('.csv') && file.type !== 'text/csv') {
      setUploadError('Please upload a valid .csv file containing traffic records.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = parseTrafficCSV(content);
        if (parsed.length === 0) {
          setUploadError('No valid traffic records found in CSV. Expected headers: speed, volume, density, road, timestamp.');
          return;
        }
        onUpdateRecords(parsed);
        setUploadSuccess(`Successfully loaded and clustered ${parsed.length} traffic observations.`);
        setCurrentPage(1);
      } catch (err) {
        setUploadError('Failed to parse CSV file. Please verify structure.');
      }
    };
    reader.readAsText(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  // Export Filtered CSV
  const handleDownloadCSV = () => {
    const headers = [
      'record_id',
      'road_segment',
      'timestamp',
      'speed_kmh',
      'traffic_volume_vehh',
      'traffic_density_vehkm',
      'weather',
      'kmeans_cluster',
      'dbscan_cluster',
      'traffic_status',
      'latitude',
      'longitude',
    ];

    const rows = filteredAndSortedRecords.map((r) => [
      `"${r.record_id}"`,
      `"${r.road_segment}"`,
      `"${r.timestamp}"`,
      r.speed,
      r.traffic_volume,
      r.traffic_density,
      `"${r.weather}"`,
      r.kmeans_cluster !== undefined ? r.kmeans_cluster : '',
      r.dbscan_cluster !== undefined ? (r.dbscan_cluster === -1 ? 'Noise' : r.dbscan_cluster) : '',
      `"${r.traffic_status || ''}"`,
      r.latitude,
      r.longitude,
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `traffic_flow_clustering_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Weather icon helper
  const renderWeather = (weather: WeatherCondition) => {
    switch (weather) {
      case 'Rainy':
        return <span className="inline-flex items-center gap-1 text-blue-400"><CloudRain className="w-3.5 h-3.5" /> Rainy</span>;
      case 'Foggy':
        return <span className="inline-flex items-center gap-1 text-slate-400"><Cloud className="w-3.5 h-3.5" /> Foggy</span>;
      case 'Overcast':
        return <span className="inline-flex items-center gap-1 text-slate-300"><Cloud className="w-3.5 h-3.5" /> Overcast</span>;
      default:
        return <span className="inline-flex items-center gap-1 text-amber-400"><Sun className="w-3.5 h-3.5" /> Clear</span>;
    }
  };

  // Traffic status badge helper
  const renderStatus = (status?: TrafficStatus) => {
    switch (status) {
      case 'Free Flow':
        return <span className="text-emerald-400 font-medium">Free Flow</span>;
      case 'Moderate':
        return <span className="text-cyan-400 font-medium">Moderate</span>;
      case 'Heavy':
        return <span className="text-amber-400 font-medium">Heavy Flow</span>;
      case 'Congested':
        return <span className="text-rose-400 font-medium">Congested</span>;
      default:
        return <span className="text-slate-400">Normal</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div>
        <h2 className="text-xl lg:text-2xl font-bold text-white tracking-tight">
          Traffic Dataset &amp; Feature Preprocessing
        </h2>
        <p className="text-xs lg:text-sm text-slate-400 mt-1">
          Explore multi-dimensional traffic sensor records, inspect data normalization stages, and upload custom road telemetry.
        </p>
      </div>

      {/* Visual Preprocessing Workflow */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white">
              Data Preprocessing &amp; Normalization Pipeline
            </h3>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            Pipeline Validated
          </span>
        </div>

        {/* Step-by-step pipeline diagram */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-center text-xs">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Stage 1</div>
            <div className="font-semibold text-slate-200 mt-1">Raw Traffic Data</div>
            <div className="text-[11px] text-cyan-400 font-mono mt-1 tabular-nums">{records.length} records</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Stage 2</div>
            <div className="font-semibold text-slate-200 mt-1">Imputation</div>
            <div className="text-[11px] text-emerald-400 font-mono mt-1 tabular-nums">{preprocessingStats.missingValuesHandled} handled</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Stage 3</div>
            <div className="font-semibold text-slate-200 mt-1">Feature Selection</div>
            <div className="text-[11px] text-slate-400 font-mono mt-1">Speed, Vol, Dens</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Stage 4</div>
            <div className="font-semibold text-slate-200 mt-1">Engineering</div>
            <div className="text-[11px] text-slate-400 font-mono mt-1">Status LOS rules</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Stage 5</div>
            <div className="font-semibold text-slate-200 mt-1">MinMax Scaling</div>
            <div className="text-[11px] text-cyan-400 font-mono mt-1">[0, 1] range</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Stage 6</div>
            <div className="font-semibold text-slate-200 mt-1">Clustering</div>
            <div className="text-[11px] text-emerald-400 font-mono mt-1">K-Means &amp; DBSCAN</div>
          </div>
        </div>
      </div>

      {/* Upload & Drag & Drop Area */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`p-6 rounded-2xl border-2 border-dashed transition-all text-center ${
          dragActive
            ? 'border-cyan-400 bg-cyan-500/10'
            : 'border-slate-800 bg-slate-900/50 hover:border-slate-700'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={(e) => e.target.files && e.target.files[0] && handleFile(e.target.files[0])}
        />
        <div className="flex flex-col items-center justify-center gap-2">
          <div className="p-3 rounded-full bg-slate-800 text-cyan-400">
            <Upload className="w-5 h-5" />
          </div>
          <div className="text-sm font-semibold text-slate-200">
            Drag &amp; drop your Traffic CSV dataset here, or{' '}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="text-cyan-400 hover:text-cyan-300 underline underline-offset-4 cursor-pointer"
            >
              browse file
            </button>
          </div>
          <p className="text-xs text-slate-400 max-w-md">
            Supports columns: <code className="text-slate-300">speed</code>,{' '}
            <code className="text-slate-300">volume</code>, <code className="text-slate-300">density</code>,{' '}
            <code className="text-slate-300">road_segment</code>, <code className="text-slate-300">timestamp</code>. Automatically scales and re-clusters upon import.
          </p>

          {uploadError && (
            <div className="mt-2 flex items-center gap-1.5 text-xs text-rose-400 bg-rose-500/10 px-3 py-1.5 rounded-lg border border-rose-500/20">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{uploadError}</span>
            </div>
          )}

          {uploadSuccess && (
            <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{uploadSuccess}</span>
            </div>
          )}
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by Record ID or Road Segment..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadCSV}
              className="px-3 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download CSV</span>
            </button>

            <button
              onClick={onResetData}
              className="px-3 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Reset dataset to default calibrated samples"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Data</span>
            </button>
          </div>
        </div>

        {/* Dropdown Filters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 pt-2 border-t border-slate-800/80">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Traffic Status</label>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Free Flow">Free Flow</option>
              <option value="Moderate">Moderate</option>
              <option value="Heavy">Heavy Flow</option>
              <option value="Congested">Congested</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Road Segment</label>
            <select
              value={roadFilter}
              onChange={(e) => {
                setRoadFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500 truncate"
            >
              <option value="ALL">All Road Segments</option>
              {uniqueRoads.map((road) => (
                <option key={road} value={road}>
                  {road}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Weather Condition</label>
            <select
              value={weatherFilter}
              onChange={(e) => {
                setWeatherFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500"
            >
              <option value="ALL">All Weather</option>
              <option value="Clear">Clear</option>
              <option value="Rainy">Rainy</option>
              <option value="Foggy">Foggy</option>
              <option value="Overcast">Overcast</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Rows per Page</label>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none focus:border-cyan-500"
            >
              <option value={10}>10 rows</option>
              <option value={15}>15 rows</option>
              <option value={25}>25 rows</option>
              <option value={50}>50 rows</option>
            </select>
          </div>
        </div>
      </div>

      {/* Dataset Table */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold select-none">
                <th
                  onClick={() => handleSort('record_id')}
                  className="py-3 px-3.5 cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Record ID</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('road_segment')}
                  className="py-3 px-3.5 cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Road Segment</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('timestamp')}
                  className="py-3 px-3.5 cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Timestamp</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('speed')}
                  className="py-3 px-3.5 text-right cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Speed (km/h)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('traffic_volume')}
                  className="py-3 px-3.5 text-right cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Volume (veh/h)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('traffic_density')}
                  className="py-3 px-3.5 text-right cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Density (veh/km)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3.5">Weather</th>
                <th className="py-3 px-3.5 text-center">K-Means Cluster</th>
                <th className="py-3 px-3.5 text-center">DBSCAN Cluster</th>
                <th className="py-3 px-3.5">Traffic Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {paginatedRecords.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-500">
                    No traffic records matched your filter criteria.
                  </td>
                </tr>
              ) : (
                paginatedRecords.map((r) => {
                  const kmColor =
                    r.kmeans_cluster !== undefined
                      ? CLUSTER_COLORS[r.kmeans_cluster % CLUSTER_COLORS.length]
                      : '#64748b';

                  return (
                    <tr
                      key={r.record_id}
                      className="hover:bg-slate-800/40 transition-colors text-slate-300"
                    >
                      <td className="py-2.5 px-3.5 font-mono text-[11px] text-cyan-400 font-medium">
                        {r.record_id}
                      </td>
                      <td className="py-2.5 px-3.5 font-medium text-slate-200 truncate max-w-[200px]">
                        {r.road_segment}
                      </td>
                      <td className="py-2.5 px-3.5 font-mono text-[11px] text-slate-400">
                        {r.timestamp.split(' ')[1]}
                      </td>
                      <td className="py-2.5 px-3.5 text-right font-mono tabular-nums font-semibold text-slate-100">
                        {r.speed}
                      </td>
                      <td className="py-2.5 px-3.5 text-right font-mono tabular-nums text-slate-300">
                        {r.traffic_volume}
                      </td>
                      <td className="py-2.5 px-3.5 text-right font-mono tabular-nums text-slate-300">
                        {r.traffic_density}
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-300">
                        {renderWeather(r.weather)}
                      </td>
                      <td className="py-2.5 px-3.5 text-center font-mono">
                        <span
                          className="inline-block px-2 py-0.5 rounded text-[11px] font-semibold"
                          style={{
                            color: kmColor,
                            backgroundColor: `${kmColor}15`,
                            border: `1px solid ${kmColor}30`,
                          }}
                        >
                          C-{r.kmeans_cluster ?? 0}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 text-center font-mono">
                        {r.dbscan_cluster === -1 ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[11px] font-semibold text-purple-400 bg-purple-500/10 border border-purple-500/30">
                            Noise (-1)
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30">
                            Cluster {r.dbscan_cluster ?? 0}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3.5">
                        {renderStatus(r.traffic_status)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-3.5 bg-slate-950/80 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div>
            Showing{' '}
            <span className="font-mono text-slate-200">
              {filteredAndSortedRecords.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}
            </span>{' '}
            to{' '}
            <span className="font-mono text-slate-200">
              {Math.min(currentPage * pageSize, filteredAndSortedRecords.length)}
            </span>{' '}
            of <span className="font-mono text-slate-200">{filteredAndSortedRecords.length}</span>{' '}
            filtered records ({records.length} total)
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-mono text-xs">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
