/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import {
  TrendingUp,
  Gauge,
  Car,
  AlertTriangle,
  Layers,
  ArrowUpRight,
  ShieldAlert,
  Flame,
  Clock,
  Compass,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { TrafficRecord, KMeansResult, DbscanResult } from '../../types/traffic';
import { CLUSTER_COLORS } from '../../utils/mlAlgorithms';

interface OverviewDashboardProps {
  records: TrafficRecord[];
  kmeansResult: KMeansResult;
  dbscanResult: DbscanResult;
  onNavigate: (tab: string) => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  records,
  kmeansResult,
  dbscanResult,
  onNavigate,
}) => {
  // Compute summary metrics
  const stats = useMemo(() => {
    if (records.length === 0) {
      return { avgSpeed: 0, avgVolume: 0, avgDensity: 0, freeFlow: 0, moderate: 0, heavy: 0, congested: 0 };
    }

    const totalSpd = records.reduce((acc, r) => acc + r.speed, 0);
    const totalVol = records.reduce((acc, r) => acc + r.traffic_volume, 0);
    const totalDen = records.reduce((acc, r) => acc + r.traffic_density, 0);

    const counts = {
      freeFlow: records.filter((r) => r.traffic_status === 'Free Flow').length,
      moderate: records.filter((r) => r.traffic_status === 'Moderate').length,
      heavy: records.filter((r) => r.traffic_status === 'Heavy').length,
      congested: records.filter((r) => r.traffic_status === 'Congested').length,
    };

    return {
      avgSpeed: Math.round(totalSpd / records.length),
      avgVolume: Math.round(totalVol / records.length),
      avgDensity: Math.round(totalDen / records.length),
      ...counts,
    };
  }, [records]);

  // Aggregate hourly trends for the multi-metric line chart
  const timeTrends = useMemo(() => {
    const hourlyMap: Record<
      string,
      { count: number; speedSum: number; volSum: number; denSum: number }
    > = {};

    records.forEach((r) => {
      const timePart = r.timestamp.split(' ')[1] || '12:00:00';
      const hour = timePart.split(':')[0] + ':00';
      if (!hourlyMap[hour]) {
        hourlyMap[hour] = { count: 0, speedSum: 0, volSum: 0, denSum: 0 };
      }
      hourlyMap[hour].count += 1;
      hourlyMap[hour].speedSum += r.speed;
      hourlyMap[hour].volSum += r.traffic_volume;
      hourlyMap[hour].denSum += r.traffic_density;
    });

    return Object.keys(hourlyMap)
      .sort()
      .map((hour) => {
        const item = hourlyMap[hour];
        return {
          time: hour,
          speed: Math.round(item.speedSum / item.count),
          volume: Math.round(item.volSum / item.count),
          density: Math.round(item.denSum / item.count),
        };
      });
  }, [records]);

  // Cluster distribution for Donut Chart
  const clusterChartData = useMemo(() => {
    return kmeansResult.centroids.map((c, idx) => ({
      name: c.name,
      value: c.count,
      color: CLUSTER_COLORS[idx % CLUSTER_COLORS.length],
    }));
  }, [kmeansResult]);

  // Status breakdown data
  const statusPercentages = useMemo(() => {
    const n = records.length || 1;
    return [
      { name: 'Free Flow', count: stats.freeFlow, pct: Math.round((stats.freeFlow / n) * 100), color: '#10B981', border: 'border-emerald-500/30', bg: 'bg-emerald-500/10' },
      { name: 'Moderate', count: stats.moderate, pct: Math.round((stats.moderate / n) * 100), color: '#38BDF8', border: 'border-cyan-500/30', bg: 'bg-cyan-500/10' },
      { name: 'Heavy Flow', count: stats.heavy, pct: Math.round((stats.heavy / n) * 100), color: '#F59E0B', border: 'border-amber-500/30', bg: 'bg-amber-500/10' },
      { name: 'Congested', count: stats.congested, pct: Math.round((stats.congested / n) * 100), color: '#EF4444', border: 'border-rose-500/30', bg: 'bg-rose-500/10' },
    ];
  }, [records, stats]);

  return (
    <div className="space-y-6">
      {/* Title & Subtitle banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-800/80 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
            <Compass className="w-3.5 h-3.5" />
            <span>Unsupervised Traffic Pattern Intelligence</span>
          </div>
          <h2 className="text-2xl lg:text-3xl font-bold text-white tracking-tight">
            Traffic Flow Pattern Clustering
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Using <span className="text-cyan-400 font-medium">K-Means</span> partitional centroids and{' '}
            <span className="text-emerald-400 font-medium">DBSCAN</span> density reachability to identify
            congestion bottlenecks, free-flow regimes, and anomalous traffic incidents.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onNavigate('kmeans')}
            className="px-3.5 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>K-Means Model</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
          </button>
          <button
            onClick={() => onNavigate('map')}
            className="px-3.5 py-2 text-xs font-medium text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-lg shadow-md shadow-cyan-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span>GIS Traffic Map</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3.5">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Total Records</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {records.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Multi-sensor points</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Average Speed</span>
            <Gauge className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            {stats.avgSpeed} <span className="text-xs text-slate-400 font-sans">km/h</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Free-flow vs congested</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Avg Volume</span>
            <Car className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-400 font-mono tabular-nums">
            {stats.avgVolume} <span className="text-xs text-slate-400 font-sans">veh/h</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Corridor throughput</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Avg Density</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums">
            {stats.avgDensity} <span className="text-xs text-slate-400 font-sans">veh/km</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Spatial concentration</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Hotspots</span>
            <Flame className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold text-rose-400 font-mono tabular-nums">
            {dbscanResult.hotspotsCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Bottleneck zones</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">DBSCAN Outliers</span>
            <ShieldAlert className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-purple-400 font-mono tabular-nums">
            {dbscanResult.noiseCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Sensor/incident noise</p>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Multi-Metric Traffic Trend Line Chart */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Temporal Traffic Trend Analysis
              </h3>
              <p className="text-xs text-slate-400">
                Speed (km/h), Normalized Volume (veh/10h), and Density (veh/km) over 24-hr cycle
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Hourly aggregate</span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeTrends} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis
                  dataKey="time"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                />
                <YAxis
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#f8fafc',
                  }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }}
                />
                <Line
                  type="monotone"
                  dataKey="speed"
                  name="Speed (km/h)"
                  stroke="#10B981"
                  strokeWidth={2.5}
                  dot={{ r: 2.5 }}
                />
                <Line
                  type="monotone"
                  dataKey="density"
                  name="Density (veh/km)"
                  stroke="#F59E0B"
                  strokeWidth={2}
                  dot={{ r: 2 }}
                />
                <Line
                  type="monotone"
                  dataKey="volume"
                  name="Volume (veh/h)"
                  stroke="#38BDF8"
                  strokeWidth={1.5}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cluster Distribution Donut */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white">
                K-Means Cluster Distribution
              </h3>
              <span className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                K = {kmeansResult.k}
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-2">
              Proportion of traffic records assigned to each flow regime
            </p>

            <div className="h-48 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={clusterChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {clusterChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '8px',
                      fontSize: '11px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-slate-800 text-xs">
            {kmeansResult.centroids.map((c, i) => (
              <div key={i} className="flex items-center justify-between text-slate-300">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: c.color }}
                  />
                  <span className="truncate max-w-[140px]">{c.name}</span>
                </div>
                <span className="font-mono text-slate-400 tabular-nums">
                  {c.count} records ({Math.round((c.count / (records.length || 1)) * 100)}%)
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Traffic Status Breakdown & Latest Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Breakdown Section */}
        <div className="lg:col-span-1 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <h3 className="text-sm font-semibold text-white mb-1">
            Traffic Status Classifications
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Rule-calibrated level-of-service (LOS) based on speed and density
          </p>

          <div className="space-y-3">
            {statusPercentages.map((item, idx) => (
              <div key={idx} className={`p-3 rounded-xl border ${item.border} ${item.bg}`}>
                <div className="flex items-center justify-between text-xs font-semibold mb-1">
                  <span style={{ color: item.color }}>{item.name}</span>
                  <span className="font-mono text-white tabular-nums">{item.count} pts ({item.pct}%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${item.pct}%`, backgroundColor: item.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Latest Traffic Insights Panel */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded bg-cyan-500/10 text-cyan-400">
                  <TrendingUp className="w-4 h-4" />
                </span>
                <h3 className="text-sm font-semibold text-white">
                  Latest Unsupervised Traffic Insights
                </h3>
              </div>
              <span className="text-[11px] text-cyan-400 font-mono">Real-time extracted</span>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Pattern characteristics identified by running K-Means partitioning &amp; DBSCAN density scans
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-amber-400 font-medium mb-1">
                  <Flame className="w-3.5 h-3.5" />
                  <span>Morning Bottleneck Period</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Peak congestion window occurs between <strong className="text-white">07:50 – 08:50 AM</strong> with average speed dropping to <strong>19 km/h</strong> and density peaking at <strong>86 veh/km</strong> on Central Boulevard.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-cyan-400 font-medium mb-1">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Optimal Cluster Separation</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Silhouette score reaches <strong className="text-white font-mono">{kmeansResult.silhouetteScore.toFixed(3)}</strong> at K = {kmeansResult.k}, confirming clear demarcation between free-flow corridors and heavy queues.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-purple-400 font-medium mb-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Incident &amp; Outlier Detection</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  DBSCAN successfully flagged <strong className="text-white font-mono">{dbscanResult.noiseCount} anomalous data points</strong>, isolating accident slowdowns and unusual detector spikes without distorting normal centroids.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-emerald-400 font-medium mb-1">
                  <Gauge className="w-3.5 h-3.5" />
                  <span>Capacity Recommendation</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Harbor Bay Bridge and Metro Expressway operate in the unstable congestion regime during 17:30–18:30; adaptive ramp metering advised.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Machine Learning Method: K-Means (Euclidean) + DBSCAN (Density eps=0.28)</span>
            <button
              onClick={() => onNavigate('insights')}
              className="text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1 cursor-pointer"
            >
              <span>View All Recommendations</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
