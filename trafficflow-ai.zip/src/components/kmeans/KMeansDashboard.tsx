/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import {
  PieChart as PieIcon,
  ScatterChart as ScatterIcon,
  Sliders,
  TrendingDown,
  Layers,
  Sparkles,
  Info,
  HelpCircle,
  Activity,
  CheckCircle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ScatterChart,
  Scatter,
  ZAxis,
  Cell,
  Legend,
} from 'recharts';
import { TrafficRecord, KMeansResult } from '../../types/traffic';
import { CLUSTER_COLORS } from '../../utils/mlAlgorithms';

interface KMeansDashboardProps {
  records: TrafficRecord[];
  kmeansResult: KMeansResult;
  onKChange: (newK: number) => void;
}

export const KMeansDashboard: React.FC<KMeansDashboardProps> = ({
  records,
  kmeansResult,
  onKChange,
}) => {
  // Scatter plot data: Speed (X) vs Density (Y), with cluster coloring
  const scatterData = useMemo(() => {
    return records.map((r) => ({
      speed: r.speed,
      density: r.traffic_density,
      volume: r.traffic_volume,
      cluster: r.kmeans_cluster ?? 0,
      road: r.road_segment,
      status: r.traffic_status,
      id: r.record_id,
      color: CLUSTER_COLORS[(r.kmeans_cluster ?? 0) % CLUSTER_COLORS.length],
    }));
  }, [records]);

  // Scatter by clusters for legend grouping
  const clusterGroups = useMemo(() => {
    const groups: Record<number, any[]> = {};
    for (let c = 0; c < kmeansResult.k; c++) {
      groups[c] = [];
    }
    scatterData.forEach((pt) => {
      if (groups[pt.cluster]) {
        groups[pt.cluster].push(pt);
      }
    });
    return groups;
  }, [scatterData, kmeansResult.k]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Algorithm Overview */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
              <PieIcon className="w-3.5 h-3.5" />
              <span>Partitional Unsupervised Learning</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              K-Means Traffic Flow Clustering
            </h2>
            <p className="text-xs lg:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              K-Means partitions traffic observations into <span className="text-cyan-400 font-mono font-medium">K groups</span> based on similarity in speed, volume, and density. It iteratively minimizes the sum of squared Euclidean distances (Inertia) between sensor points and cluster centroids.
            </p>
          </div>

          {/* Interactive K Controller */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/90 shrink-0 min-w-[240px]">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                Cluster Count (K)
              </span>
              <span className="font-mono text-cyan-400 font-bold text-sm">
                K = {kmeansResult.k}
              </span>
            </div>

            <input
              type="range"
              min={2}
              max={8}
              step={1}
              value={kmeansResult.k}
              onChange={(e) => onKChange(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />

            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
              <span>K=2</span>
              <span>K=4 (Default)</span>
              <span>K=8</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cluster Evaluation Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Silhouette Score */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Silhouette Score</span>
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums">
            {kmeansResult.silhouetteScore.toFixed(3)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {kmeansResult.silhouetteScore > 0.5 ? 'Strong separation' : 'Reasonable structure'} ([-1 to +1])
          </p>
        </div>

        {/* Davies-Bouldin Index */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Davies-Bouldin Index</span>
            <TrendingDown className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            {kmeansResult.daviesBouldinIndex.toFixed(3)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Lower is better (similarity ratio)
          </p>
        </div>

        {/* Inertia / SSE */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Inertia (SSE)</span>
            <Layers className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums">
            {kmeansResult.inertia.toFixed(1)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Sum of squared centroid distances
          </p>
        </div>

        {/* Convergence status */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Convergence Status</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-lg font-bold text-slate-200">
            Converged
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            K-Means++ initialization applied
          </p>
        </div>
      </div>

      {/* Visualizations: Elbow Curve & Scatter Plot */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Elbow Method Chart */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Elbow Method Curve (Optimal K Selection)
              </h3>
              <p className="text-xs text-slate-400">
                Inertia vs Number of Clusters K. Optimal elbow typically observed at K=4.
              </p>
            </div>
            <div className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
              Elbow = 4
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={kmeansResult.elbowData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis
                  dataKey="k"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  label={{ value: 'Number of Clusters (K)', position: 'insideBottom', offset: -4, fill: '#64748b', fontSize: 10 }}
                />
                <YAxis
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '11px',
                  }}
                  formatter={(val: any) => [`${val} SSE`, 'Inertia']}
                />
                <Line
                  type="monotone"
                  dataKey="inertia"
                  stroke="#38BDF8"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#38BDF8' }}
                  activeDot={{ r: 6, fill: '#10B981' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 2D Cluster Scatter Plot (Speed vs Density) */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Traffic Flow Scatter Plot (Speed vs Density)
              </h3>
              <p className="text-xs text-slate-400">
                Fundamental Greenshields diagram showing cluster segregation
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>{records.length} Points</span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis
                  type="number"
                  dataKey="density"
                  name="Density"
                  unit=" veh/km"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  label={{ value: 'Traffic Density (veh/km)', position: 'insideBottom', offset: -4, fill: '#64748b', fontSize: 10 }}
                />
                <YAxis
                  type="number"
                  dataKey="speed"
                  name="Speed"
                  unit=" km/h"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  label={{ value: 'Speed (km/h)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }}
                />
                <ZAxis range={[35, 35]} />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ payload }) => {
                    if (payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-xs space-y-1">
                          <p className="font-semibold text-white">{data.road}</p>
                          <p className="text-cyan-400 font-mono">Cluster {data.cluster} ({data.status})</p>
                          <div className="text-slate-300 font-mono text-[11px]">
                            Speed: {data.speed} km/h · Density: {data.density} veh/km
                          </div>
                          <div className="text-slate-400 font-mono text-[11px]">
                            Volume: {data.volume} veh/h · ID: {data.id}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                {Object.keys(clusterGroups).map((clusterIdx) => {
                  const idx = Number(clusterIdx);
                  return (
                    <Scatter
                      key={idx}
                      name={`Cluster ${idx}`}
                      data={clusterGroups[idx]}
                      fill={CLUSTER_COLORS[idx % CLUSTER_COLORS.length]}
                    />
                  );
                })}
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Centroids Table */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
        <h3 className="text-sm font-semibold text-white mb-1">
          K-Means Cluster Centroids &amp; Operational Semantics
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Calculated mathematical center points for each discovered traffic regime
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold">
                <th className="py-2.5 px-4">Cluster ID</th>
                <th className="py-2.5 px-4">Semantic Label</th>
                <th className="py-2.5 px-4 text-right">Avg Speed (km/h)</th>
                <th className="py-2.5 px-4 text-right">Avg Volume (veh/h)</th>
                <th className="py-2.5 px-4 text-right">Avg Density (veh/km)</th>
                <th className="py-2.5 px-4 text-center">Observations</th>
                <th className="py-2.5 px-4">Traffic Management Strategy</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {kmeansResult.centroids.map((c) => (
                <tr key={c.cluster} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold" style={{ color: c.color }}>
                    Cluster {c.cluster}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }} />
                      <span>{c.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-semibold text-white tabular-nums">
                    {c.speed}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-300 tabular-nums">
                    {c.traffic_volume}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-300 tabular-nums">
                    {c.traffic_density}
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-cyan-400 tabular-nums">
                    {c.count} ({Math.round((c.count / (records.length || 1)) * 100)}%)
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">
                    {c.status === 'Free Flow' && 'Maintain coordinated green wave; speed limit enforcement'}
                    {c.status === 'Moderate' && 'Monitor volume build-up; dynamically calibrate phase splits'}
                    {c.status === 'Heavy' && 'Trigger arterial queue-spill prevention; advise alternate routes'}
                    {c.status === 'Congested' && 'Deploy incident response; activate expressway ramp metering'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
